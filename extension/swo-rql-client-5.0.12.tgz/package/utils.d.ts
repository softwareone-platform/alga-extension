import { BinaryExpression, ComparissonExpression, Expression, LogicalExpression, Optional, UnaryExpression } from './operators';
export declare function serializeExpression(expression: Expression, opts?: {
    isToPreserveValueWhiteSpace?: boolean;
}): string;
/**
 * Used to map an operation to the items of an array.
 *
 * Example:
 * Entity Buyer { sellers: Sellers[] }
 * Entity Seller { id: string; name: string; }
 *
 * Original Operation: eq('seller.name','John')
 * Map: mapOperationToArrayItems('sellers', 'name', originalOperation)
 * Result:
 *
 * {
 *   field: 'sellers',
 *   operator: 'any',
 *   value: {
 *     field: 'name',
 *     operator: 'eq',
 *     value: 'John'
 *   }
 * }
 *
 * @param arrayFieldName field name of the array
 * @param itemFieldName field name of the item inside the array
 * @param operation the original operation to the mapped
 * @param arrayOperator which operator to use to map to array 'any' or 'all'
 * @returns mapped operation
 */
export declare function mapOperationToArrayItems(arrayFieldName: string, itemFieldName: string, operation: ComparissonExpression, arrayOperator?: 'any' | 'all'): Expression;
export declare function convertOperationValueToNull(expression: Expression, valueToConvert: string): Expression;
export declare function isUnaryExpression(expression: Optional<Expression>): expression is UnaryExpression;
export declare function isLogicalExpression(expression: Optional<Expression>): expression is LogicalExpression;
export declare function isBinaryExpression(expression: Optional<Expression>): expression is BinaryExpression;
/**
 * Groups select paths by their root property recursively.
 * @param selects
 */
export declare function groupSelects(selects: string[]): string[];
