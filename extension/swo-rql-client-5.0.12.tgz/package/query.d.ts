import { Expression } from './operators/operators';
import { Paths } from './operators/types';
export type OrderByDirection = 'asc' | 'desc';
type SelectPaths<TObject extends object> = Paths<TObject> | '*';
export interface RqlConfig<TObject extends object, TPath extends Paths<TObject>> {
    expand?: SelectPaths<TObject>[];
    exclude?: SelectPaths<TObject>[];
    filter?: Expression | null;
    namedFilter?: string;
    orderBy?: ([TPath, OrderByDirection] | TPath)[];
    limit?: number;
    offset?: number;
}
interface RqlQueryOptions {
    isToPreserveValueWhiteSpace?: boolean;
    isToUseGroupedSelects?: boolean;
}
export declare class RqlQuery<TObject extends object = object> {
    #private;
    opts: RqlQueryOptions;
    static IS_IMMUTABLE: boolean;
    constructor(query?: RqlQuery<TObject>);
    constructor(opts?: RqlQueryOptions);
    get operators(): import('./operators/operators').Query<TObject>;
    get operation(): Expression | null;
    get order(): (string | [string, OrderByDirection])[];
    get limit(): number | undefined;
    get offset(): number | undefined;
    applyNamedFilter(filterName: string): RqlQuery<TObject>;
    exclude(...paths: SelectPaths<TObject>[]): RqlQuery<TObject>;
    /**
     * Alias for expand method
     */
    select(...paths: SelectPaths<TObject>[]): RqlQuery<TObject>;
    expand(...paths: SelectPaths<TObject>[]): RqlQuery<TObject>;
    orderBy<TPath extends Paths<TObject>>(...fields: ([TPath, OrderByDirection] | TPath | `-${TPath}`)[]): RqlQuery<TObject>;
    filter(expression: Expression): RqlQuery<TObject>;
    addAndOperation(expression: Expression): RqlQuery<TObject>;
    addOrOperation(expression: Expression): RqlQuery<TObject>;
    paging(offset: number, limit: number): RqlQuery<TObject>;
    noPaging(): RqlQuery<TObject>;
    config<TPath extends Paths<TObject>>(config: RqlConfig<TObject, TPath>): RqlQuery<TObject>;
    build(): string;
    getQueryParams(): Record<string, string>;
    export<TPath extends Paths<TObject>>(): RqlConfig<TObject, TPath>;
    clone(): RqlQuery<TObject>;
    get [Symbol.toStringTag](): string;
    toString(): string;
    private serializeSelect;
    private serializeOrderBy;
    private serializePaging;
}
export {};
