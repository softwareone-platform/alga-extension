var B = (r) => {
  throw TypeError(r);
};
var w = (r, t, e) => t.has(r) || B("Cannot " + e);
var i = (r, t, e) => (w(r, t, "read from private field"), e ? e.call(r) : t.get(r)), g = (r, t, e) => t.has(r) ? B("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(r) : t.set(r, e), l = (r, t, e, n) => (w(r, t, "write to private field"), n ? n.call(r, e) : t.set(r, e), e);
function W() {
  return new b();
}
function U() {
  return new b();
}
function s(r, t, e) {
  return {
    field: r,
    value: t,
    operator: e
  };
}
function p(r, t) {
  return {
    field: r,
    operator: t
  };
}
class b {
  eq(t, e) {
    return s(t, e, "eq");
  }
  neq(t, e) {
    return s(t, e, "neq");
  }
  gt(t, e) {
    return s(t, e, "gt");
  }
  ge(t, e) {
    return s(t, e, "ge");
  }
  lt(t, e) {
    return s(t, e, "lt");
  }
  le(t, e) {
    return s(t, e, "le");
  }
  inList(t, e) {
    return s(t, e, "in");
  }
  outList(t, e) {
    return s(t, e, "out");
  }
  iLike(t, e) {
    return s(t, e, "ilike");
  }
  startsWith(t, e) {
    return s(t, e, "startsWith");
  }
  endsWith(t, e) {
    return s(t, e, "endsWith");
  }
  contains(t, e) {
    return s(t, e, "contains");
  }
  any(t, e) {
    return e ? s(t, e, "any") : p(t, "any");
  }
  all(t, e) {
    return e ? s(t, e, "all") : p(t, "all");
  }
  and(...t) {
    return {
      value: t,
      operator: "and"
    };
  }
  or(...t) {
    return {
      value: t,
      operator: "or"
    };
  }
  not(t) {
    return {
      value: [t],
      operator: "not"
    };
  }
  empty(t) {
    return p(t, "empty");
  }
  notEmpty(t) {
    return p(t, "notEmpty");
  }
  isNull(t) {
    return p(t, "null");
  }
  isNotNull(t) {
    return p(t, "notNull");
  }
}
function m(r, t) {
  switch (r.operator) {
    case "ne":
    case "eq":
      return r.value === void 0 || r.value === "" ? "" : r.value === null ? m({ operator: r.operator === "eq" ? "null" : "notNull", field: r.field }, t) : `${r.operator}(${r.field},${encodeURIComponent(S(r.value, t))})`;
    case "gt":
    case "ge":
    case "lt":
    case "le":
    case "ilike":
      return r.value ? `${r.operator}(${r.field},${encodeURIComponent(S(r.value, t))})` : "";
    case "startsWith":
      return r.value ? m({ ...r, operator: "ilike", value: `${I(r.value, t)}*` }, t) : "";
    case "endsWith":
      return r.value ? m({ ...r, operator: "ilike", value: `*${I(r.value, t)}` }, t) : "";
    case "contains":
      return r.value ? m({ ...r, operator: "ilike", value: `*${I(r.value, t)}*` }, t) : "";
    case "neq":
      return m({ ...r, operator: "ne" }, t);
    case "out":
    case "in":
      return !r.value || Array.isArray(r.value) && r.value.length === 0 || !Array.isArray(r.value) ? "" : r.value.some((n) => n === null) ? m(
        {
          operator: r.operator === "in" ? "or" : "and",
          value: [
            { operator: r.operator === "in" ? "null" : "notNull", field: r.field },
            { operator: r.operator, field: r.field, value: r.value.filter((n) => n !== null) }
          ]
        },
        t
      ) : `${r.operator}(${r.field},${encodeURIComponent(S(r.value, t))})`;
    case "and":
    case "or": {
      const e = r.value.filter((n) => !!n).map((n) => m(n, t)).filter((n) => !!n);
      return e.length === 0 ? "" : e.length === 1 ? e[0] : `${r.operator}(${e.join(",")})`;
    }
    case "not": {
      const e = r.value.filter((n) => !!n).map((n) => m(n, t)).filter((n) => !!n);
      return e.length === 0 ? "" : `${r.operator}(${e.join(",")})`;
    }
    case "empty":
    case "null":
      return `eq(${r.field},${r.operator}())`;
    case "notEmpty":
      return `ne(${r.field},empty())`;
    case "notNull":
      return `ne(${r.field},null())`;
    case "any":
    case "all": {
      if (!("value" in r))
        return `${r.operator}(${r.field})`;
      if (!r.value)
        return "";
      const e = m(r.value, t);
      return e ? `${r.operator}(${r.field},${e})` : "";
    }
  }
}
function S(r, t) {
  if (Array.isArray(r))
    return "(" + r.map((e) => S(e, t)).join(",") + ")";
  if (typeof r == "object")
    throw new Error(`Cannot serialise object: ${JSON.stringify(r)}`);
  return typeof r == "string" ? (r = r.replace(/["]/g, ""), t != null && t.isToPreserveValueWhiteSpace ? `"${r}"` : `"${r.trim()}"`) : r.toString();
}
function N(r, t, e, n = "any") {
  switch (e.operator) {
    case "null":
    case "empty":
    case "notNull":
    case "notEmpty":
      return {
        field: r,
        operator: n,
        value: {
          field: t,
          operator: e.operator
        }
      };
  }
  return "value" in e ? {
    field: r,
    operator: n,
    value: {
      field: t,
      value: e.value,
      operator: e.operator
    }
  } : {
    field: r,
    operator: n,
    value: {
      field: t,
      operator: e.operator
    }
  };
}
function k(r, t) {
  switch (r.operator) {
    case "eq":
    case "ne":
    case "neq":
      if (r.value === t)
        return {
          field: r.field,
          operator: r.operator,
          value: null
        };
      break;
    case "gt":
    case "ge":
    case "lt":
    case "le":
    case "ilike":
    case "startsWith":
    case "endsWith":
    case "contains":
      if (r.value === t)
        throw new Error(`Operation "${r.operator}" does not support null conversion`);
      break;
    case "in":
    case "out":
      if (!r.value)
        return r;
      if (!Array.isArray(r.value))
        throw new Error(`Operation "${r.operator}" does not support null conversion when value is not an array`);
      if (r.value.includes(t))
        return {
          field: r.field,
          operator: r.operator,
          value: r.value.map((e) => e === t ? null : e)
        };
      break;
  }
  return r;
}
function I(r, t) {
  return t != null && t.isToPreserveValueWhiteSpace ? r : typeof r == "string" ? r.trim() : r;
}
function T(r) {
  return r ? r.operator === "null" || r.operator === "empty" || r.operator === "notNull" || r.operator === "notEmpty" : !1;
}
function L(r) {
  return r ? r.operator === "or" || r.operator === "and" || r.operator === "not" : !1;
}
function z(r) {
  return r ? !T(r) && !L(r) : !1;
}
function A(r) {
  const t = {};
  return r.forEach((e) => {
    const [n, ...a] = e.split(".");
    t[n] || (t[n] = []), a.length > 0 && t[n].push(a.join("."));
  }), Object.entries(t).map(([e, n]) => {
    if (n.length === 0)
      return e;
    const a = A(n);
    return `${e}(${a.join(",")})`;
  });
}
var y, $, u, f, h, d, E, v;
const c = class c {
  constructor(t) {
    g(this, y);
    g(this, $);
    g(this, u);
    g(this, f);
    g(this, h);
    g(this, d);
    g(this, E);
    g(this, v);
    if (l(this, y, []), l(this, $, []), l(this, u, null), l(this, f, []), l(this, E, U()), this.opts = { isToPreserveValueWhiteSpace: !1, isToUseGroupedSelects: !1 }, t && typeof t == "object" && !(t instanceof c)) {
      this.opts = t;
      return;
    }
    t instanceof c && (this.opts = { ...t.opts }, l(this, y, [...i(t, y)]), l(this, $, [...i(t, $)]), l(this, u, i(t, u)), l(this, f, [...i(t, f)]), l(this, d, i(t, d)), l(this, h, i(t, h)), l(this, v, i(t, v)));
  }
  get operators() {
    return i(this, E);
  }
  get operation() {
    return i(this, u);
  }
  get order() {
    return i(this, f);
  }
  get limit() {
    return i(this, d);
  }
  get offset() {
    return i(this, h);
  }
  applyNamedFilter(t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return l(e, v, t), e;
  }
  exclude(...t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return l(e, $, [...i(this, $), ...t]), e;
  }
  /**
   * Alias for expand method
   */
  select(...t) {
    return this.expand(...t);
  }
  expand(...t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return l(e, y, [...i(this, y), ...t]), e;
  }
  orderBy(...t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return l(e, f, t), e;
  }
  filter(t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return l(e, u, t), e;
  }
  addAndOperation(t) {
    const { and: e } = this.operators, n = c.IS_IMMUTABLE ? this.clone() : this;
    return l(n, u, this.operation ? e(this.operation, t) : t), n;
  }
  addOrOperation(t) {
    const { or: e } = this.operators, n = c.IS_IMMUTABLE ? this.clone() : this;
    return l(n, u, this.operation ? e(this.operation, t) : t), n;
  }
  paging(t, e) {
    const n = c.IS_IMMUTABLE ? this.clone() : this;
    return l(n, h, t), l(n, d, e), n;
  }
  noPaging() {
    const t = c.IS_IMMUTABLE ? this.clone() : this;
    return l(t, h, void 0), l(t, d, void 0), t;
  }
  config(t) {
    const e = c.IS_IMMUTABLE ? this.clone() : this;
    return t.expand && l(e, y, [...i(e, y), ...t.expand]), t.exclude && l(e, $, [...i(e, $), ...t.exclude]), t.filter && (t.filter, l(e, u, t.filter)), t.orderBy && l(e, f, t.orderBy), t.offset, t.limit && (l(e, h, t.offset ?? 0), l(e, d, t.limit)), t.namedFilter && l(e, v, t.namedFilter), e;
  }
  build() {
    const t = [], e = this.serializeSelect(), n = this.serializeOrderBy(), a = i(this, u) ? m(i(this, u), this.opts) : "", o = this.serializePaging();
    return e && e !== "*" && t.push(`select=${e}`), i(this, v) && t.push(`filter(${encodeURIComponent(i(this, v))})`), a && t.push(a), n && t.push(`order=${n}`), o && t.push(o), t.join("&");
  }
  getQueryParams() {
    const t = this.serializeSelect(), e = this.serializeOrderBy(), n = i(this, u) ? m(i(this, u), this.opts) : "", a = {};
    return typeof i(this, d) == "number" && (a.limit = i(this, d).toString()), typeof i(this, h) == "number" && (a.offset = i(this, h).toString()), t && t !== "*" && (a.select = t), n && (a[n] = ""), e && (a.order = e), a;
  }
  export() {
    return {
      expand: i(this, y),
      exclude: i(this, $),
      filter: i(this, u),
      orderBy: i(this, f),
      limit: i(this, d),
      offset: i(this, h)
    };
  }
  clone() {
    return new c(this);
  }
  get [Symbol.toStringTag]() {
    return this.build();
  }
  toString() {
    return this.build();
  }
  serializeSelect() {
    const t = i(this, y).includes("*") ? "*" : "", e = i(this, y).filter((o) => o !== "*"), n = i(this, $).includes("*") ? "*" : "", a = i(this, $).filter((o) => o !== "*");
    return `${[
      ...[n, ...this.opts.isToUseGroupedSelects ? A(a) : a].filter(Boolean).map((o) => typeof o == "string" || typeof o == "number" ? `-${o}` : ""),
      ...[t, ...this.opts.isToUseGroupedSelects ? A(e) : e].filter(Boolean).map((o) => typeof o == "string" || typeof o == "number" ? `${o}` : "")
    ].filter((o) => !!o).join(",")}`;
  }
  serializeOrderBy() {
    if (i(this, f).length > 1)
      return `(${i(this, f).map((t) => {
        if (Array.isArray(t)) {
          const [e, n] = t;
          return `${n === "desc" ? "-" : ""}${e}`;
        }
        return t;
      }).join(",")})`;
    if (i(this, f).length === 1) {
      if (Array.isArray(i(this, f)[0])) {
        const [t, e] = i(this, f)[0];
        return `${e === "desc" ? "-" : ""}${t}`;
      }
      return i(this, f)[0];
    }
    return "";
  }
  serializePaging() {
    const t = [];
    return typeof i(this, h) == "number" && t.push(`offset=${i(this, h)}`), typeof i(this, d) == "number" && t.push(`limit=${i(this, d)}`), t.join("&");
  }
};
y = new WeakMap(), $ = new WeakMap(), u = new WeakMap(), f = new WeakMap(), h = new WeakMap(), d = new WeakMap(), E = new WeakMap(), v = new WeakMap(), c.IS_IMMUTABLE = !1;
let M = c;
export {
  M as RqlQuery,
  k as convertOperationValueToNull,
  U as getExpressionBuilder,
  W as getOperationBuilder,
  z as isBinaryExpression,
  L as isLogicalExpression,
  T as isUnaryExpression,
  N as mapOperationToArrayItems
};
//# sourceMappingURL=index.js.map
