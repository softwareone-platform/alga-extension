import { GetFieldType, Paths } from './types';
export interface ILike<TReturn, TObject extends object> {
    iLike<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath> extends string | undefined | null ? string : never): TReturn;
}
