import { Paths } from './types';
export interface NotNull<TReturn, TObject extends object> {
    isNotNull<TPath extends Paths<TObject>>(path: TPath): TReturn;
}
