import { Expression } from './operators';
import { ArrayPaths } from './types';
export interface Any<TReturn, TObject extends object> {
    any(path: ArrayPaths<TObject>, value?: Expression): TReturn;
}
