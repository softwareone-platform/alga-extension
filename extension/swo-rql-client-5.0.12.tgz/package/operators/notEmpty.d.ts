import { Paths } from './types';
export interface NotEmpty<TReturn, TObject extends object> {
    notEmpty<TPath extends Paths<TObject>>(path: TPath): TReturn;
}
