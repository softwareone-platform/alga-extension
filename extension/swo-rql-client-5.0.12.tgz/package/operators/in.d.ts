import { GetFieldType, Paths } from './types';
export interface In<TReturn, TObject extends object> {
    inList<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>[]): TReturn;
}
