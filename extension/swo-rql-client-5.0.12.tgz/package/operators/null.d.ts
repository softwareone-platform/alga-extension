import { Paths } from './types';
export interface Null<TReturn, TObject extends object> {
    isNull<TPath extends Paths<TObject>>(path: TPath): TReturn;
}
