import { Paths } from './types';
export interface Empty<TReturn, TObject extends object> {
    empty<TPath extends Paths<TObject>>(path: TPath): TReturn;
}
