import { GetFieldType, Paths } from './types';
export interface Le<TReturn, TObject extends object> {
    le<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
