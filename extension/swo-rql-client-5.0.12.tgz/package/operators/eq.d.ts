import { GetFieldType, Paths } from './types';
export interface Eq<TReturn, TObject extends object> {
    eq<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
