import { GetFieldType, Paths } from './types';
export interface StartsWith<TReturn, TObject extends object> {
    startsWith<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath> extends string | undefined | null ? string : never): TReturn;
}
