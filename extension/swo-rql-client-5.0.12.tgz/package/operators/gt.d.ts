import { GetFieldType, Paths } from './types';
export interface Gt<TReturn, TObject extends object> {
    gt<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
