import { GetFieldType, Paths } from './types';
export interface Lt<TReturn, TObject extends object> {
    lt<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
