import { All } from './all';
import { Any } from './any';
import { Contains } from './contains';
import { Empty } from './empty';
import { EndsWith } from './endsWith';
import { Eq } from './eq';
import { Ge } from './ge';
import { Gt } from './gt';
import { ILike } from './ilike';
import { In } from './in';
import { Le } from './le';
import { Lt } from './lt';
import { Neq } from './neq';
import { NotEmpty } from './notEmpty';
import { NotNull } from './notNull';
import { Null } from './null';
import { Out } from './out';
import { StartsWith } from './startsWith';
export type Optional<T> = T | null | undefined;
export type UnaryOperator = 'empty' | 'notEmpty' | 'null' | 'notNull' | 'any' | 'all';
export type BinaryOperator = 'eq' | 'ne' | 'neq' | 'gt' | 'ge' | 'lt' | 'le' | 'in' | 'out' | 'ilike' | 'startsWith' | 'endsWith' | 'contains' | 'all' | 'any';
export type LogicalOperator = 'and' | 'or' | 'not';
export type ComparissonOperator = BinaryOperator | UnaryOperator;
export type Operator = LogicalOperator | ComparissonOperator;
export interface UnaryExpression {
    field: string;
    operator: UnaryOperator;
}
export interface BinaryExpression {
    field: string;
    value: unknown;
    operator: BinaryOperator;
}
export interface LogicalExpression {
    value: Array<Optional<Expression>>;
    operator: LogicalOperator;
}
export type ComparissonExpression = BinaryExpression | UnaryExpression;
export type Expression = ComparissonExpression | LogicalExpression;
/** @deprecated Use Expression instead. */
export type Operation = Expression;
export type Operators<TObject extends object> = Any<BinaryExpression | UnaryExpression, TObject> & All<BinaryExpression | UnaryExpression, TObject> & Eq<BinaryExpression, TObject> & Neq<BinaryExpression, TObject> & Gt<BinaryExpression, TObject> & Ge<BinaryExpression, TObject> & Lt<BinaryExpression, TObject> & Le<BinaryExpression, TObject> & In<BinaryExpression, TObject> & Out<BinaryExpression, TObject> & ILike<BinaryExpression, TObject> & StartsWith<BinaryExpression, TObject> & EndsWith<BinaryExpression, TObject> & Contains<BinaryExpression, TObject> & Empty<UnaryExpression, TObject> & Null<UnaryExpression, TObject> & NotNull<UnaryExpression, TObject> & NotEmpty<UnaryExpression, TObject>;
export type Expressions = Array<Optional<Expression>>;
export type Operations = Expressions;
export interface Query<TObject extends object> extends Operators<TObject> {
    and(...operations: Expressions): Expression;
    or(...operations: Expressions): Expression;
    not(operation: Optional<Expression>): Expression;
}
/** @deprecated Use getExpressionBuilder instead. */
export declare function getOperationBuilder<T extends object>(): Query<T>;
export declare function getExpressionBuilder<T extends object>(): Query<T>;
