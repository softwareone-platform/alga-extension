export type GetIndexedField<T, K> = K extends keyof T ? T[K] : K extends `${number}` ? 'length' extends keyof T ? number extends T['length'] ? number extends keyof T ? T[number] : undefined : undefined : undefined : undefined;
export type NullOrUndefined = undefined | null;
export type FieldWithPossiblyUndefined<T, Key> = GetFieldType<Exclude<T, NullOrUndefined>, Key> | Extract<T, NullOrUndefined>;
export type IndexedFieldWithPossiblyUndefined<T, Key> = GetIndexedField<Exclude<T, NullOrUndefined>, Key> | Extract<T, NullOrUndefined>;
export type GetFieldType<T, P> = P extends `${infer Left}.${infer Right}` ? Left extends keyof Exclude<T, undefined> ? FieldWithPossiblyUndefined<Exclude<T, undefined>[Left], Right> | Extract<T, undefined> : Left extends `${infer FieldKey}[${infer IndexKey}]` ? FieldKey extends keyof T ? FieldWithPossiblyUndefined<IndexedFieldWithPossiblyUndefined<T[FieldKey], IndexKey>, Right> : undefined : undefined : P extends keyof T ? T[P] : P extends `${infer FieldKey}[${infer IndexKey}]` ? FieldKey extends keyof T ? IndexedFieldWithPossiblyUndefined<T[FieldKey], IndexKey> : undefined : IndexedFieldWithPossiblyUndefined<T, P>;
export type Prev = [never, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, ...0[]];
export type Join<K, P> = K extends string | number ? (P extends string | number ? `${K}${'' extends P ? '' : '.'}${P}` : never) : never;
export type ComplexPaths<T, D extends number = 4> = [D] extends [never] ? never : T extends object ? {
    [K in keyof T]-?: K extends string | number ? `${K}` | Join<K, ComplexPaths<T[K], Prev[D]>> : never;
}[keyof T] : '';
export type Paths<T, D extends number = 4> = [D] extends [never] ? never : T extends Array<infer TItem> ? Paths<TItem, D> | '' : T extends object ? {
    [K in keyof T]-?: K extends string | number ? `${K}` | Join<K, Paths<T[K], Prev[D]>> : never;
}[keyof T] : '';
export type LimitedPaths<T> = Paths<T, 2>;
export type MinusPaths<T, D extends number = 4> = [D] extends [never] ? never : T extends object ? {
    [K in keyof T]-?: K extends string | number ? `-${K}` | Join<K, Paths<T[K], Prev[D]>> : never;
}[keyof T] : '';
export type Leaves<T, D extends number = 4> = [D] extends [never] ? never : T extends object ? {
    [K in keyof T]-?: Join<K, Leaves<T[K], Prev[D]>>;
}[keyof T] : '';
export type ArrayPaths<T, D extends number = 4> = [D] extends [never] ? never : T extends object ? {
    [K in keyof T]-?: K extends string | number ? (Exclude<T[K], NullOrUndefined> extends Array<unknown> ? `${K}` : never) | Join<K, ArrayPaths<T[K], Prev[D]>> : never;
}[keyof T] : T extends Array<unknown> ? '' : never;
