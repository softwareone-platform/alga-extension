import { GetFieldType, Paths } from './types';
export interface Out<TReturn, TObject extends object> {
    outList<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>[]): TReturn;
}
