import { GetFieldType, Paths } from './types';
export interface EndsWith<TReturn, TObject extends object> {
    endsWith<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath> extends string | undefined | null ? string : never): TReturn;
}
