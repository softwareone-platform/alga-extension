import { GetFieldType, Paths } from './types';
export interface Contains<TReturn, TObject extends object> {
    contains<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath> extends string | undefined | null ? string : never): TReturn;
}
