import { GetFieldType, Paths } from './types';
export interface Neq<TReturn, TObject extends object> {
    neq<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
