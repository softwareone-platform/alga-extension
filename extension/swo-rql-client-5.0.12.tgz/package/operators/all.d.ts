import { Expression } from './operators';
import { ArrayPaths } from './types';
export interface All<TReturn, TObject extends object> {
    all(path: ArrayPaths<TObject>, value?: Expression): TReturn;
}
