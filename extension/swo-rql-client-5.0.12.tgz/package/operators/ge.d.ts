import { GetFieldType, Paths } from './types';
export interface Ge<TReturn, TObject extends object> {
    ge<TPath extends Paths<TObject>>(path: TPath, value: GetFieldType<TObject, TPath>): TReturn;
}
