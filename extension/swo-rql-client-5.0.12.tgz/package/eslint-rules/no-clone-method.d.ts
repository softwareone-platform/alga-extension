import { ESLintUtils } from '@typescript-eslint/utils';
export declare const createRule: <Options extends readonly unknown[], MessageIds extends string>({ meta, name, ...rule }: Readonly<ESLintUtils.RuleWithMetaAndName<Options, MessageIds, unknown>>) => ESLintUtils.RuleModule<MessageIds, Options, unknown, ESLintUtils.RuleListener>;
export declare const noCloneMethod: ESLintUtils.RuleModule<"noCloneMethod" | "noCloneMethodSuggestion", [], unknown, ESLintUtils.RuleListener>;
