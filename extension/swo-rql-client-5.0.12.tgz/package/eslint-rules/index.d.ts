export { noUnusedReturn } from './no-unused-return';
export { noCloneMethod } from './no-clone-method';
export declare const rules: {
    'no-unused-return': import('@typescript-eslint/utils/dist/ts-eslint').RuleModule<"unusedReturnValue" | "unusedReturnValueSuggestion", [], unknown, import('@typescript-eslint/utils/dist/ts-eslint').RuleListener>;
    'no-clone-method': import('@typescript-eslint/utils/dist/ts-eslint').RuleModule<"noCloneMethod" | "noCloneMethodSuggestion", [], unknown, import('@typescript-eslint/utils/dist/ts-eslint').RuleListener>;
};
declare const _default: {
    rules: {
        'no-unused-return': import('@typescript-eslint/utils/dist/ts-eslint').RuleModule<"unusedReturnValue" | "unusedReturnValueSuggestion", [], unknown, import('@typescript-eslint/utils/dist/ts-eslint').RuleListener>;
        'no-clone-method': import('@typescript-eslint/utils/dist/ts-eslint').RuleModule<"noCloneMethod" | "noCloneMethodSuggestion", [], unknown, import('@typescript-eslint/utils/dist/ts-eslint').RuleListener>;
    };
};
export default _default;
