import { ESLintUtils as i } from "@typescript-eslint/utils";
const d = i.RuleCreator(
  (o) => `https://github.com/swo/mpt/swo-web-libraries/tree/main/libs/rql-client/src/eslint-rules/${o}.md`
), m = d({
  name: "no-clone-method",
  meta: {
    type: "problem",
    docs: {
      description: "Disallow the use of the clone method on RqlQuery objects"
    },
    fixable: void 0,
    schema: [],
    messages: {
      noCloneMethod: "The RqlQuery class is set to become immutable by default so the use of the clone() method will become redundant and should be avoided.",
      noCloneMethodSuggestion: "Consider using other RqlQuery methods or creating a new query instance instead."
    }
  },
  defaultOptions: [],
  create(o) {
    return {
      CallExpression(s) {
        if (s.callee.type !== "MemberExpression")
          return;
        const { object: l, property: r } = s.callee;
        if (r.type !== "Identifier" || r.name !== "clone")
          return;
        let t;
        try {
          t = i.getParserServices(o);
        } catch {
        }
        if (t && t.program) {
          const e = t.program.getTypeChecker(), a = t.esTreeNodeToTSNodeMap.get(l), n = e.getTypeAtLocation(a);
          if (!e.typeToString(n).includes("RqlQuery"))
            return;
        }
        o.report({
          node: s,
          messageId: "noCloneMethod"
        });
      }
    };
  }
}), p = i.RuleCreator(
  (o) => `https://github.com/swo/mpt/swo-web-libraries/tree/main/libs/rql-client/src/eslint-rules/${o}.md`
), y = [
  "exclude",
  "expand",
  "orderBy",
  "filter",
  "addAndOperation",
  "addOrOperation",
  "paging",
  "noPaging",
  "config",
  "applyNamedFilter",
  "clone"
], g = p({
  name: "no-unused-return",
  meta: {
    type: "problem",
    docs: {
      description: "Require using the return value of RqlQuery methods to facilitate immutable migration"
    },
    fixable: void 0,
    schema: [],
    messages: {
      unusedReturnValue: "The return value of RqlQuery.{{methodName}}() must be used. RqlQuery methods are set to become immutable and return a new instance so any return values not used will be lost.",
      unusedReturnValueSuggestion: "Consider assigning the result to a variable or chaining the method call."
    }
  },
  defaultOptions: [],
  create(o) {
    return {
      CallExpression(s) {
        if (s.callee.type !== "MemberExpression")
          return;
        const { object: l, property: r } = s.callee;
        if (r.type !== "Identifier" || !y.includes(r.name))
          return;
        let t;
        try {
          t = i.getParserServices(o);
        } catch {
        }
        if (t && t.program) {
          const n = t.program.getTypeChecker(), u = t.esTreeNodeToTSNodeMap.get(l), c = n.getTypeAtLocation(u);
          if (!n.typeToString(c).includes("RqlQuery"))
            return;
        } else
          return;
        const e = s.parent;
        (e == null ? void 0 : e.type) === "AssignmentExpression" || (e == null ? void 0 : e.type) === "VariableDeclarator" || (e == null ? void 0 : e.type) === "ReturnStatement" || (e == null ? void 0 : e.type) === "ArrowFunctionExpression" || (e == null ? void 0 : e.type) === "CallExpression" || (e == null ? void 0 : e.type) === "MemberExpression" || (e == null ? void 0 : e.type) === "ConditionalExpression" || (e == null ? void 0 : e.type) === "LogicalExpression" || (e == null ? void 0 : e.type) === "BinaryExpression" || (e == null ? void 0 : e.type) === "UnaryExpression" || (e == null ? void 0 : e.type) === "Property" || (e == null ? void 0 : e.type) === "ArrayExpression" || o.report({
          node: s,
          messageId: "unusedReturnValue",
          data: {
            methodName: r.name
          }
        });
      }
    };
  }
}), h = {
  "no-unused-return": g,
  "no-clone-method": m
}, R = {
  rules: h
};
export {
  R as default,
  m as noCloneMethod,
  g as noUnusedReturn,
  h as rules
};
//# sourceMappingURL=index.js.map
