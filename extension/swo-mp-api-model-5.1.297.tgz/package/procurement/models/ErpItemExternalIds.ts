/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ErpItemExternalIds = {
  operations?: string;
  vendor?: string | null;
};

