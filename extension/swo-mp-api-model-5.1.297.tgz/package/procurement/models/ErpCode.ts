/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ErpCode = {
  identifier?: string | null;
  value?: string | null;
  type?: number | null;
  version?: string | null;
};

