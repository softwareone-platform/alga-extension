/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpItem } from './ErpItem';
import type { ListMetadata } from './ListMetadata';
export type ErpItemListResponse = {
  $meta?: ListMetadata;
  data?: Array<ErpItem>;
};

