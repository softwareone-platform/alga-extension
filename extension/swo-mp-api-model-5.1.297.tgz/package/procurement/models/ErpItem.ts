/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpEntityAuditBag } from './ErpEntityAuditBag';
import type { ErpItemAttributes } from './ErpItemAttributes';
import type { ErpItemExternalIds } from './ErpItemExternalIds';
import type { ErpItemStatus } from './ErpItemStatus';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type ErpItem = {
  id?: string;
  audit?: ErpEntityAuditBag;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  status?: ErpItemStatus;
  attributes?: ErpItemAttributes;
  externalIds?: ErpItemExternalIds;
};

