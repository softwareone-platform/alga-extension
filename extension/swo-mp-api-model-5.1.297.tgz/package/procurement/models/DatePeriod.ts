/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DatePeriod = {
  start?: string | null;
  end?: string | null;
};

