/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ErpAddress = {
  name?: string | null;
  name2?: string | null;
  email?: string | null;
  customerNo?: string | null;
  addressLine1?: string | null;
  addressLine2?: string | null;
  addressLine3?: string | null;
  city?: string | null;
  postCode?: string | null;
  county?: string | null;
  country?: string | null;
  contactName?: string | null;
  contactNo?: string | null;
  contactEmail?: string | null;
  contactPhone?: string | null;
  code?: string | null;
};

