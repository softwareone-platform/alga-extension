/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpItemNavisionAttributes } from './ErpItemNavisionAttributes';
export type ErpItemAttributes = {
  navision?: ErpItemNavisionAttributes;
};

