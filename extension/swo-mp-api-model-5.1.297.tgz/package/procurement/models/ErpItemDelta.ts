/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { ErpItem } from './ErpItem';
export type ErpItemDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ErpItem | null;
  readonly isDefined?: boolean;
};

