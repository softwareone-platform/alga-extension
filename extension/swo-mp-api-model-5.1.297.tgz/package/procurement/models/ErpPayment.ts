/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ErpPayment = {
  methodCode?: string | null;
  termsCode?: string | null;
  discountDate?: string | null;
  discountPercent?: number | null;
};

