/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpAddress } from './ErpAddress';
export type ErpAddressList = {
  billTo?: ErpAddress;
  licenseTo?: ErpAddress | null;
  sellTo?: ErpAddress | null;
  shipTo?: ErpAddress | null;
};

