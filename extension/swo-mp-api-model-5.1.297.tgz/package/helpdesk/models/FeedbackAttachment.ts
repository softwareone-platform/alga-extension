/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Feedback } from './Feedback';
import type { File } from './File';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type FeedbackAttachment = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Represents the feedback this attachment belongs to.
   */
  feedback?: Feedback;
  /**
   * Represents the file this attachment belongs to.
   */
  file?: File;
};

