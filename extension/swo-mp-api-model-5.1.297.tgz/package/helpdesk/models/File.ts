/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FileType } from './FileType';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
/**
 * Represents a file in the helpdesk module
 */
export type File = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  icon?: string | null;
  revision?: number;
  /**
   * Name of the attachment.
   */
  name?: string;
  /**
   * Specifies the type of the file, such as attachment or icon
   */
  type?: FileType;
  /**
   * Represents the name of the file associated with the attachment.
   */
  filename?: string;
  /**
   * Indicates the size of the file in bytes.
   */
  size?: number | null;
  /**
   * Represents the MIME type of the file content.
   */
  contentType?: string;
  /**
   * Provides a description of the attachment.
   */
  description?: string;
  /**
   * Indicates whether the attachment has been marked as deleted.
   */
  isDeleted?: boolean;
};

