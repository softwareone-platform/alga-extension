/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatParticipant } from './ChatParticipant';
import type { DeltaNode } from './DeltaNode';
export type ChatParticipantDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ChatParticipant | null;
  readonly isDefined?: boolean;
};

