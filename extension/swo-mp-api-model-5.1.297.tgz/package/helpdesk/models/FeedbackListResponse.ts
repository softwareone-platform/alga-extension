/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Feedback } from './Feedback';
import type { ListMetadata } from './ListMetadata';
export type FeedbackListResponse = {
  $meta?: ListMetadata;
  data?: Array<Feedback>;
};

