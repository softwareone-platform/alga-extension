/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatLink } from './ChatLink';
import type { ListMetadata } from './ListMetadata';
export type ChatLinkListResponse = {
  $meta?: ListMetadata;
  data?: Array<ChatLink>;
};

