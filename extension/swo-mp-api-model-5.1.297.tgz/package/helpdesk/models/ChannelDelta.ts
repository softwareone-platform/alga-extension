/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Channel } from './Channel';
import type { DeltaNode } from './DeltaNode';
export type ChannelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Channel | null;
  readonly isDefined?: boolean;
};

