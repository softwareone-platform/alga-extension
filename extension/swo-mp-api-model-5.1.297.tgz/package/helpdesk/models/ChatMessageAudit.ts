/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type ChatMessageAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  deleted?: PlatformObjectEvent | null;
  undeleted?: PlatformObjectEvent | null;
  madePublic?: PlatformObjectEvent | null;
  madePrivate?: PlatformObjectEvent | null;
};

