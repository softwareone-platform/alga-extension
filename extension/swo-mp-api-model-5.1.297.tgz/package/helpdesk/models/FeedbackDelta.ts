/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { Feedback } from './Feedback';
export type FeedbackDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Feedback | null;
  readonly isDefined?: boolean;
};

