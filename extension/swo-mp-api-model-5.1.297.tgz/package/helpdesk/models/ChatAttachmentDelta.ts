/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatAttachment } from './ChatAttachment';
import type { DeltaNode } from './DeltaNode';
export type ChatAttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ChatAttachment | null;
  readonly isDefined?: boolean;
};

