/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type ChannelAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  archived?: PlatformObjectEvent | null;
  activated?: PlatformObjectEvent | null;
};

