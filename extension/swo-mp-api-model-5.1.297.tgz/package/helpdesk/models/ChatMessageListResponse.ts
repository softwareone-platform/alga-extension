/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatMessage } from './ChatMessage';
import type { ListMetadata } from './ListMetadata';
export type ChatMessageListResponse = {
  $meta?: ListMetadata;
  data?: Array<ChatMessage>;
};

