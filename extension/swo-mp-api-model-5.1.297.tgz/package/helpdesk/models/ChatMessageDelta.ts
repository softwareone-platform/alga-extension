/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatMessage } from './ChatMessage';
import type { DeltaNode } from './DeltaNode';
export type ChatMessageDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ChatMessage | null;
  readonly isDefined?: boolean;
};

