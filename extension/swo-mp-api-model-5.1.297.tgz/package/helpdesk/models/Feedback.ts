/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FeedbackAttachment } from './FeedbackAttachment';
import type { FeedbackStatus } from './FeedbackStatus';
import type { PlatformAccount } from './PlatformAccount';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformIdentity } from './PlatformIdentity';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type Feedback = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Gets or sets the description associated with the feedback.
   */
  description?: string | null;
  /**
   * Represents the user who requested the feedback
   */
  requester?: PlatformIdentity | null;
  /**
   * Reference to the Account object
   */
  account?: PlatformAccount | null;
  /**
   * Gets or sets the status associated with the feedback.
   */
  status?: FeedbackStatus;
  /**
   * Gets or sets the rating associated with the feedback.
   */
  rating?: number;
  /**
   * Gets or sets the notes associated with the feedback.
   */
  notes?: string | null;
  /**
   * Gets or sets the internal notes associated with the feedback.
   */
  internalNotes?: string | null;
  /**
   * Gets or sets the externalId associated with the feedback.
   */
  externalId?: string | null;
  metaData?: Record<string, any> | null;
  /**
   * Represents the attachments associated with the feedback.
   */
  attachments?: Array<FeedbackAttachment> | null;
};

