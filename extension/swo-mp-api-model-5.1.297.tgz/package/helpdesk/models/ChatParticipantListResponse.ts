/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatParticipant } from './ChatParticipant';
import type { ListMetadata } from './ListMetadata';
export type ChatParticipantListResponse = {
  $meta?: ListMetadata;
  data?: Array<ChatParticipant>;
};

