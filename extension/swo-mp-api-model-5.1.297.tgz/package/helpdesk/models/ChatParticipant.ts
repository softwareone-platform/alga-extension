/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { ChatMessage } from './ChatMessage';
import type { ChatParticipantAudit } from './ChatParticipantAudit';
import type { ParticipantRole } from './ParticipantRole';
import type { ParticipantStatistics } from './ParticipantStatistics';
import type { ParticipantStatus } from './ParticipantStatus';
import type { PlatformAccount } from './PlatformAccount';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformIdentity } from './PlatformIdentity';
export type ChatParticipant = {
  id?: string;
  audit?: ChatParticipantAudit;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * Represents the chat this participant belongs to.
   */
  chat?: Chat;
  /**
   * Represents the identity of the participant - user, api token, or service identity
   */
  identity?: PlatformIdentity;
  /**
   * Represents the account context of the identity of the chat participant.
   */
  account?: PlatformAccount;
  /**
   * Represents the role of the chat participant within the chat.
   */
  role?: ParticipantRole;
  /**
   * Represents the status of the chat participant, indicating whether they are active, suspended, or exited.
   */
  status?: ParticipantStatus;
  /**
   * The last message in the chat read by this participant.
   */
  lastReadMessage?: ChatMessage | null;
  /**
   * Useful statistics about the chat from the viewpoint of this participant.
   */
  statistics?: ParticipantStatistics;
};

