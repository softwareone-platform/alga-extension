/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type ChatAttachment = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Represents the chat this attachment belongs to.
   */
  chat?: Chat;
  /**
   * Represents the name of the file, including its extension.
   */
  filename?: string;
  /**
   * Indicates the size of the file in bytes.
   */
  size?: number | null;
  /**
   * Represents the MIME type of the file content.
   */
  contentType?: string;
  /**
   * Provides an optional description of the attachment.
   */
  description?: string | null;
};

