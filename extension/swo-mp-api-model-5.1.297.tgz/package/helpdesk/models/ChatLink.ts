/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type ChatLink = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Represents the chat this link belongs to.
   */
  chat?: Chat;
  /**
   * Represents the URI for link.
   */
  uri?: string;
};

