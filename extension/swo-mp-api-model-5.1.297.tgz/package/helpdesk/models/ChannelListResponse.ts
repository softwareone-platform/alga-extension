/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Channel } from './Channel';
import type { ListMetadata } from './ListMetadata';
export type ChannelListResponse = {
  $meta?: ListMetadata;
  data?: Array<Channel>;
};

