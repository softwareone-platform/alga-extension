/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatAttachment } from './ChatAttachment';
import type { ChatLink } from './ChatLink';
import type { ChatMessage } from './ChatMessage';
import type { ChatParticipant } from './ChatParticipant';
import type { ChatStatistics } from './ChatStatistics';
import type { ChatType } from './ChatType';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type Chat = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Gets or sets the description associated with the chat.
   */
  description?: string | null;
  /**
   * Represents the type of chat, indicating whether it is a direct message, group chat, channel, or support case.
   */
  type?: ChatType;
  /**
   * Represents the participants in the chat.
   */
  participants?: Array<ChatParticipant>;
  /**
   * The last message communicated in the chat by any participant.
   */
  lastMessage?: ChatMessage;
  /**
   * Helpful statistics about this chat.
   */
  statistics?: ChatStatistics;
  /**
   * Represents the links associated with the chat.
   */
  links?: Array<ChatLink>;
  /**
   * Represents the attachments associated with the chat.
   */
  attachments?: Array<ChatAttachment>;
};

