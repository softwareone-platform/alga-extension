/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { ChatMessageAudit } from './ChatMessageAudit';
import type { ChatParticipant } from './ChatParticipant';
import type { MessageVisibility } from './MessageVisibility';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type ChatMessage = {
  id?: string;
  audit?: ChatMessageAudit;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * Represents the chat this message belongs to.
   */
  chat?: Chat;
  /**
   * Sender of the chat message.
   */
  sender?: ChatParticipant;
  /**
   * Content of the chat message.
   */
  content?: string;
  /**
   * Visibility of the chat message, indicating whether it is public or private.
   */
  visibility?: MessageVisibility;
  /**
   * Set to true when the message should be considered deleted
   */
  isDeleted?: boolean;
};

