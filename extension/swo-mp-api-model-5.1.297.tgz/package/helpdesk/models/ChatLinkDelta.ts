/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatLink } from './ChatLink';
import type { DeltaNode } from './DeltaNode';
export type ChatLinkDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ChatLink | null;
  readonly isDefined?: boolean;
};

