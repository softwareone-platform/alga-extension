/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChatAttachment } from './ChatAttachment';
import type { ListMetadata } from './ListMetadata';
export type ChatAttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<ChatAttachment>;
};

