/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { DeltaNode } from './DeltaNode';
export type ChatDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Chat | null;
  readonly isDefined?: boolean;
};

