/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Chat } from './Chat';
import type { ListMetadata } from './ListMetadata';
export type ChatListResponse = {
  $meta?: ListMetadata;
  data?: Array<Chat>;
};

