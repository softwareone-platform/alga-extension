/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChannelAudit } from './ChannelAudit';
import type { Chat } from './Chat';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { UserGroup } from './UserGroup';
export type Channel = {
  id?: string;
  audit?: ChannelAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * Gets or sets the associated chat for the channel.
   */
  chat?: Chat;
  /**
   * Channel moderator group list.
   */
  moderators?: Array<UserGroup>;
  /**
   * ```True``` if the channel is endorsed; otherwise, ```false```.
   */
  isEndorsed?: boolean;
};

