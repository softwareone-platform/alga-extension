/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { FooterAudit } from './FooterAudit';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type Footer = {
  id?: string;
  audit?: FooterAudit;
  $meta?: PlatformEntityMetadata | null;
  languageCode?: string;
  content?: string | null;
  isDefault?: boolean;
  status?: string;
};

