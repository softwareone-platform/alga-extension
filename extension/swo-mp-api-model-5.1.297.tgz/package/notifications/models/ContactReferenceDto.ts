/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ContactReferenceDto = {
  id?: string | null;
  email?: string | null;
};

