/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BuyerReferenceDto } from './BuyerReferenceDto';
import type { ContactReferenceDto } from './ContactReferenceDto';
import type { ContentDto } from './ContentDto';
import type { RecipientsDto } from './RecipientsDto';
import type { ReferenceDto } from './ReferenceDto';
/**
 * Represents a batch request for sending notifications, supporting both raw and templated content.
 */
export type BatchRequest = {
  /**
   * @deprecated
   */
  category?: ReferenceDto | null;
  /**
   * @deprecated
   */
  subject?: string | null;
  /**
   * @deprecated
   */
  body?: string | null;
  /**
   * @deprecated
   */
  contacts?: Array<ContactReferenceDto> | null;
  /**
   * @deprecated
   */
  account?: ReferenceDto | null;
  /**
   * @deprecated
   */
  buyer?: BuyerReferenceDto | null;
  /**
   * Represents the content of a notification batch request, which can include either templated or raw content.
   */
  content?: ContentDto | null;
  /**
   * Represents the recipients of a notification message, including account, buyer, user, and contact details.
   */
  recipients?: RecipientsDto | null;
};

