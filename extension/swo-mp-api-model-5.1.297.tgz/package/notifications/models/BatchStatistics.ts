/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BatchStatistics = {
  bounced?: number;
  complained?: number;
  discarded?: number;
  failed?: number;
  queued?: number;
  sent?: number;
};

