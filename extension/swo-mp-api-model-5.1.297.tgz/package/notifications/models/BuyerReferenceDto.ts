/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BuyerExternalIdsDto } from './BuyerExternalIdsDto';
export type BuyerReferenceDto = {
  id?: string | null;
  externalIds?: BuyerExternalIdsDto | null;
};

