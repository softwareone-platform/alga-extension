/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ReferenceDto } from './ReferenceDto';
export type ContactDto = {
  email?: string | null;
  optOuts?: Array<ReferenceDto>;
  name?: string | null;
};

