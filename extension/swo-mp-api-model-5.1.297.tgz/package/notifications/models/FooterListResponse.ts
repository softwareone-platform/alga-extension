/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Footer } from './Footer';
import type { ListMetadata } from './ListMetadata';
export type FooterListResponse = {
  $meta?: ListMetadata;
  data?: Array<Footer>;
};

