/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountSettingsSenderDto } from './AccountSettingsSenderDto';
export type AccountSettingsDto = {
  footer?: string | null;
  sender?: AccountSettingsSenderDto;
};

