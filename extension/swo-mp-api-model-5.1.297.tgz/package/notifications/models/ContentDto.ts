/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RawContentDto } from './RawContentDto';
import type { TemplatedContentDto } from './TemplatedContentDto';
/**
 * Represents the content of a notification batch request, which can include either templated or raw content.
 */
export type ContentDto = {
  /**
   * Represents the content of a templated message, including the template reference and associated data.
   */
  templated?: TemplatedContentDto | null;
  /**
   * Represents the raw content of a message, including its category, subject, and body.
   */
  raw?: RawContentDto | null;
};

