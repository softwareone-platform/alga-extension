/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Attachment } from './Attachment';
import type { BatchAudit } from './BatchAudit';
import type { BatchStatistics } from './BatchStatistics';
import type { Category } from './Category';
import type { NotificationTemplate } from './NotificationTemplate';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type Batch = {
  id?: string;
  audit?: BatchAudit;
  $meta?: PlatformEntityMetadata | null;
  account?: AccountQueryModel | null;
  attachments?: Array<Attachment>;
  body?: string | null;
  category?: Category;
  template?: NotificationTemplate | null;
  statistics?: BatchStatistics;
  subject?: string;
  status?: string;
  type?: string;
};

