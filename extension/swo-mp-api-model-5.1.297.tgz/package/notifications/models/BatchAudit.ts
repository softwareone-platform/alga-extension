/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type BatchAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  completed?: PlatformObjectEvent | null;
  processed?: PlatformObjectEvent | null;
};

