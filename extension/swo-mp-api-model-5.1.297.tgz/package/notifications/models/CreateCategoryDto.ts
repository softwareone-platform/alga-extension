/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * CreateCategoryDto
 */
export type CreateCategoryDto = {
  name?: string;
  description?: string;
  optOutAllowed?: boolean;
  note?: string | null;
  deleteAllowed?: boolean | null;
};

