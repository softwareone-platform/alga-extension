/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Contact } from './Contact';
import type { ListMetadata } from './ListMetadata';
export type ContactListResponse = {
  $meta?: ListMetadata;
  data?: Array<Contact>;
};

