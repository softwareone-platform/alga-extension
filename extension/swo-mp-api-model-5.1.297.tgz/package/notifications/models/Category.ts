/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CategoryAudit } from './CategoryAudit';
import type { MessageStatistics } from './MessageStatistics';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type Category = {
  id?: string;
  audit?: CategoryAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  description?: string;
  optOutAllowed?: boolean;
  status?: string;
  note?: string | null;
  deleteAllowed?: boolean;
  statistics?: MessageStatistics | null;
  lastUsed?: string | null;
};

