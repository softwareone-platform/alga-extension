/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Attachment = {
  id?: string;
  readonly href?: string | null;
  name?: string;
  fileName?: string;
  fileSize?: number;
  contentType?: string;
};

