/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Entity Note Dto
 */
export type EntityNoteDto = {
  note?: string | null;
};

