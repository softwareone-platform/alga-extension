/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountSettingsDto } from './AccountSettingsDto';
import type { DeltaNode } from './DeltaNode';
export type AccountSettingsDtoDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: AccountSettingsDto | null;
  readonly isDefined?: boolean;
};

