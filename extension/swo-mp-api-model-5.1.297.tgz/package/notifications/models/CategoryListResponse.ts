/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Category } from './Category';
import type { ListMetadata } from './ListMetadata';
export type CategoryListResponse = {
  $meta?: ListMetadata;
  data?: Array<Category>;
};

