/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ContactDto } from './ContactDto';
import type { DeltaNode } from './DeltaNode';
export type ContactDtoDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ContactDto | null;
  readonly isDefined?: boolean;
};

