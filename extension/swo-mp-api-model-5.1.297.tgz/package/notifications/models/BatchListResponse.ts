/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Batch } from './Batch';
import type { ListMetadata } from './ListMetadata';
export type BatchListResponse = {
  $meta?: ListMetadata;
  data?: Array<Batch>;
};

