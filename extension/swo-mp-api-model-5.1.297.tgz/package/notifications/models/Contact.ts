/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Category } from './Category';
import type { ContactAudit } from './ContactAudit';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { UserQueryModel } from './UserQueryModel';
export type Contact = {
  id?: string;
  audit?: ContactAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  blockedReason?: string | null;
  email?: string;
  optOuts?: Array<Category>;
  status?: string;
  user?: UserQueryModel | null;
};

