/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type CategoryAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  published?: PlatformObjectEvent | null;
  unpublished?: PlatformObjectEvent | null;
  deleted?: PlatformObjectEvent | null;
};

