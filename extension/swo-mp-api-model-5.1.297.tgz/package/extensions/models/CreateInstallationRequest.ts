/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InvitationEntity } from './InvitationEntity';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateInstallationRequest = {
  extension?: RequestObjectLink;
  invitation?: InvitationEntity | null;
  modules?: Array<RequestObjectLink> | null;
};

