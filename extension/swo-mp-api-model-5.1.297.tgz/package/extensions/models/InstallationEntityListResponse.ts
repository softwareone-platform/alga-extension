/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InstallationEntity } from './InstallationEntity';
import type { ListMetadata } from './ListMetadata';
export type InstallationEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<InstallationEntity>;
};

