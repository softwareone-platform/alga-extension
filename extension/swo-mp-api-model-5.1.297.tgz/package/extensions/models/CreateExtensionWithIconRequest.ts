/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateExtensionWithIconRequest = {
  /**
   * Json representation of the Extension
   */
  Extension?: {
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
    Website?: string;
    Categories?: Array<RequestObjectLink>;
  };
  icon?: Blob;
};

