/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type InvitationEntity = {
  url?: string;
  expiresAt?: string | null;
  message?: string;
  externalId?: string | null;
  validity?: '7d' | '14d' | '1m' | '3m' | '6m' | '1y';
};

