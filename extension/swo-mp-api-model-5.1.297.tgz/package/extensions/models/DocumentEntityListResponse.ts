/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DocumentEntity } from './DocumentEntity';
import type { ListMetadata } from './ListMetadata';
export type DocumentEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<DocumentEntity>;
};

