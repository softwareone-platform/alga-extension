/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { JsonValueKind } from './JsonValueKind';
import type { RequestObjectLink } from './RequestObjectLink';
export type ExtensionUpdateWithIconModel = {
  /**
   * Json representation of the extension
   */
  extension?: {
    'Extension.Node.Name'?: string;
    'Extension.Node.Children'?: Array<DeltaNode>;
    'Extension.Path'?: string;
    'Extension.Data.Name'?: string;
    'Extension.Data.ShortDescription'?: string;
    'Extension.Data.LongDescription'?: string;
    'Extension.Data.Website'?: string;
    'Extension.Data.Categories'?: Array<RequestObjectLink>;
    'Extension.Data.Configuration.RootElement.ValueKind'?: JsonValueKind;
    'Extension.IsDefined'?: boolean;
  };
  icon?: Blob;
};

