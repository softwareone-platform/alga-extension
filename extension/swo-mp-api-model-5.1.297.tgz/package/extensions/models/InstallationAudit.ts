/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type InstallationAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  invited?: PlatformObjectEvent | null;
  installed?: PlatformObjectEvent | null;
  expired?: PlatformObjectEvent | null;
  uninstalled?: PlatformObjectEvent | null;
};

