/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { DocumentEntity } from './DocumentEntity';
export type DocumentEntityDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: DocumentEntity | null;
  readonly isDefined?: boolean;
};

