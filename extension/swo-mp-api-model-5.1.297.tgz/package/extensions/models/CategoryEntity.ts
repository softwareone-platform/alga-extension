/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CategoryAudit } from './CategoryAudit';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type CategoryEntity = {
  id?: string;
  audit?: CategoryAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  description?: string | null;
  status?: 'Active' | 'Disabled';
};

