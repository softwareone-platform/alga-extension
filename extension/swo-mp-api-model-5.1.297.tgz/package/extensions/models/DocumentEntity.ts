/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DocumentAudit } from './DocumentAudit';
import type { ExtensionEntity } from './ExtensionEntity';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type DocumentEntity = {
  id?: string;
  audit?: DocumentAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  type?: string;
  description?: string;
  status?: 'Draft' | 'Published' | 'Unpublished' | 'Deleted';
  filename?: string | null;
  size?: number | null;
  contentType?: string;
  url?: string;
  language?: string;
  extension?: ExtensionEntity;
};

