/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ExtensionEventEntity = {
  event?: string;
  filter?: string;
  path?: string;
  task?: boolean;
};

