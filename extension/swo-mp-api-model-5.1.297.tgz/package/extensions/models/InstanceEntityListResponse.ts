/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InstanceEntity } from './InstanceEntity';
import type { ListMetadata } from './ListMetadata';
export type InstanceEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<InstanceEntity>;
};

