/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type InstanceAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  connecting?: PlatformObjectEvent | null;
  running?: PlatformObjectEvent | null;
  disconnected?: PlatformObjectEvent | null;
};

