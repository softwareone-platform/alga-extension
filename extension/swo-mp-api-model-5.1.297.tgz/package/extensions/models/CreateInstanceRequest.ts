/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ExtensionMetaEntity } from './ExtensionMetaEntity';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateInstanceRequest = {
  extension?: RequestObjectLink;
  meta?: ExtensionMetaEntity;
  externalId?: string;
  version?: string;
  channel?: any;
};

