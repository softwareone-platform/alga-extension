/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ExtensionEntity } from './ExtensionEntity';
import type { ExtensionEventEntity } from './ExtensionEventEntity';
import type { ExtensionScheduleEntity } from './ExtensionScheduleEntity';
import type { IntegrationPointEntity } from './IntegrationPointEntity';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type ExtensionMetaEntity = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  version?: string;
  extension?: ExtensionEntity;
  placeholders?: Array<IntegrationPointEntity>;
  openapi?: string;
  events?: Array<ExtensionEventEntity>;
  schedules?: Array<ExtensionScheduleEntity>;
};

