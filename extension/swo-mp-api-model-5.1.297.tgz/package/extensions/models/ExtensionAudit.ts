/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type ExtensionAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  public?: PlatformObjectEvent | null;
  private?: PlatformObjectEvent | null;
};

