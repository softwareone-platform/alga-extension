/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { ExtensionEntity } from './ExtensionEntity';
import type { InstallationAudit } from './InstallationAudit';
import type { InvitationEntity } from './InvitationEntity';
import type { ModuleQueryModel } from './ModuleQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type InstallationEntity = {
  id?: string;
  audit?: InstallationAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  account?: AccountQueryModel | null;
  extension?: ExtensionEntity;
  status?: 'Invited' | 'Installed' | 'Uninstalled' | 'Expired';
  configuration?: any;
  invitation?: InvitationEntity | null;
  modules?: Array<ModuleQueryModel> | null;
};

