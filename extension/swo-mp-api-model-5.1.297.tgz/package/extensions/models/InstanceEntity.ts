/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChannelEntity } from './ChannelEntity';
import type { ExtensionEntity } from './ExtensionEntity';
import type { ExtensionMetaEntity } from './ExtensionMetaEntity';
import type { InstanceAudit } from './InstanceAudit';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type InstanceEntity = {
  id?: string;
  audit?: InstanceAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  extension?: ExtensionEntity;
  meta?: ExtensionMetaEntity;
  externalId?: string;
  status?: 'Connecting' | 'Disconnected' | 'Running' | 'Deleted';
  channel?: ChannelEntity | null;
};

