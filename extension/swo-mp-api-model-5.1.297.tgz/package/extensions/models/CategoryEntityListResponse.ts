/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CategoryEntity } from './CategoryEntity';
import type { ListMetadata } from './ListMetadata';
export type CategoryEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<CategoryEntity>;
};

