/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { InstallationEntity } from './InstallationEntity';
export type InstallationEntityDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: InstallationEntity | null;
  readonly isDefined?: boolean;
};

