/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { CategoryEntity } from './CategoryEntity';
import type { ExtensionAudit } from './ExtensionAudit';
import type { ExtensionMetaEntity } from './ExtensionMetaEntity';
import type { ExtensionServiceDetailsEntity } from './ExtensionServiceDetailsEntity';
import type { ExtensionStatistics } from './ExtensionStatistics';
import type { ModuleQueryModel } from './ModuleQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type ExtensionEntity = {
  id?: string;
  audit?: ExtensionAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  vendor?: AccountQueryModel;
  shortDescription?: string | null;
  longDescription?: string | null;
  website?: string;
  status?: 'Private' | 'Public' | 'Deleted';
  categories?: Array<CategoryEntity> | null;
  modules?: Array<ModuleQueryModel> | null;
  statistics?: ExtensionStatistics;
  configuration?: any;
  meta?: ExtensionMetaEntity | null;
  service?: ExtensionServiceDetailsEntity | null;
};

