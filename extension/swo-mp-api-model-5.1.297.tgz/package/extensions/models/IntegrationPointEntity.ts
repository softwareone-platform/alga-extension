/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type IntegrationPointEntity = {
  id?: string;
  name?: string;
  icon?: string;
  placeholder?: string;
  href?: string;
};

