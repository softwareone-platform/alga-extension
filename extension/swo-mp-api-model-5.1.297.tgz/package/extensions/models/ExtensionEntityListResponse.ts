/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ExtensionEntity } from './ExtensionEntity';
import type { ListMetadata } from './ListMetadata';
export type ExtensionEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<ExtensionEntity>;
};

