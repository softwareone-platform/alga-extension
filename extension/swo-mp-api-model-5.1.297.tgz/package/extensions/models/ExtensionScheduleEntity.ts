/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ExtensionScheduleEntity = {
  id?: string;
  path?: string;
  name?: string;
  description?: string;
  cron?: string;
};

