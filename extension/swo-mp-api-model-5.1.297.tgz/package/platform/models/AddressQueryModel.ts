/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddressQueryModel = {
  addressLine1: string;
  addressLine2?: string | null;
  postCode: string;
  city: string;
  state: string;
  country: string;
};

