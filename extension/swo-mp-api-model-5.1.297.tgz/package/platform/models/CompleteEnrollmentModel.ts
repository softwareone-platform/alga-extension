/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CertificateExternalIds } from './CertificateExternalIds';
import type { RequestObjectLink } from './RequestObjectLink';
export type CompleteEnrollmentModel = {
  template?: RequestObjectLink;
  externalIds?: CertificateExternalIds;
};

