/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProductRequest = {
  /**
   * Json representation of the product
   */
  product?: {
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
    Website?: string;
  };
  icon?: Blob;
};

