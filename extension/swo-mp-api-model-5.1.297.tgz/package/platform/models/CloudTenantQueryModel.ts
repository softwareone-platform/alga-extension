/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { CloudTenantExternalIdsQueryModel } from './CloudTenantExternalIdsQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type CloudTenantQueryModel = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  account?: AccountQueryModel | null;
  externalIds?: CloudTenantExternalIdsQueryModel | null;
  status?: string;
  type?: string;
};

