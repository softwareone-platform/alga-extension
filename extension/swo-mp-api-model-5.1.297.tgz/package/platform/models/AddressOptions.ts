/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DefaultParameterAddress } from './DefaultParameterAddress';
export type AddressOptions = {
  hintText?: string;
  defaultValue?: DefaultParameterAddress;
};

