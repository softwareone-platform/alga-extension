/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { ListMetadata } from './ListMetadata';
export type BuyerQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<BuyerQueryModel>;
};

