/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountDto } from './AccountDto';
import type { EmailDto } from './EmailDto';
import type { InvitationDto } from './InvitationDto';
import type { SetPhoneNumberDto } from './SetPhoneNumberDto';
import type { SetUserSettingsDto } from './SetUserSettingsDto';
import type { UserGroupDto } from './UserGroupDto';
import type { UserProfileDto } from './UserProfileDto';
export type CreateAccountUserDto = {
  id?: string | null;
  email?: EmailDto | null;
  firstName?: string | null;
  lastName?: string | null;
  phone?: SetPhoneNumberDto | null;
  settings?: SetUserSettingsDto | null;
  notes?: string | null;
  /**
   * @deprecated
   */
  user?: UserProfileDto | null;
  account?: AccountDto;
  groups: Array<UserGroupDto>;
  invitation?: InvitationDto | null;
};

