/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EnrollmentStatus = 'Draft' | 'Processing' | 'Querying' | 'Completed' | 'Failed' | 'Deleted';
