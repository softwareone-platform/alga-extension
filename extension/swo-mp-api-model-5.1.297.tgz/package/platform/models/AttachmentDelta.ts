/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Attachment } from './Attachment';
import type { DeltaNode } from './DeltaNode';
export type AttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Attachment | null;
  readonly isDefined?: boolean;
};

