/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { ExtendedParameterValueModel } from './ExtendedParameterValueModel';
export type ExtendedParameterValueModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ExtendedParameterValueModel | null;
  readonly isDefined?: boolean;
};

