/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompleteEnrollmentModel } from './CompleteEnrollmentModel';
import type { DeltaNode } from './DeltaNode';
export type CompleteEnrollmentModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: CompleteEnrollmentModel | null;
  readonly isDefined?: boolean;
};

