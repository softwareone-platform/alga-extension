/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ProgramParameterValueBagInput } from './ProgramParameterValueBagInput';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateCertificateRequest = {
  program: RequestObjectLink;
  buyer?: RequestObjectLink | null;
  licensee?: RequestObjectLink | null;
  client: RequestObjectLink;
  name?: string | null;
  parameters?: ProgramParameterValueBagInput | null;
};

