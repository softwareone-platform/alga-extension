/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AgreementAttachmentEntity } from './AgreementAttachmentEntity';
import type { ListMetadata } from './ListMetadata';
export type AgreementAttachmentEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<AgreementAttachmentEntity>;
};

