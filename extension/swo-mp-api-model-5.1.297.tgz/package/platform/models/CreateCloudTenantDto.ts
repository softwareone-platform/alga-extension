/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountDto } from './AccountDto';
import type { CloudTenantExternalIdsDto } from './CloudTenantExternalIdsDto';
import type { CloudTenantStatus } from './CloudTenantStatus';
import type { CloudTenantType } from './CloudTenantType';
export type CreateCloudTenantDto = {
  type?: CloudTenantType;
  name: string;
  status?: CloudTenantStatus;
  externalIds: CloudTenantExternalIdsDto;
  account?: AccountDto | null;
};

