/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { EnrollmentAttachmentEntity } from './EnrollmentAttachmentEntity';
export type EnrollmentAttachmentEntityDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: EnrollmentAttachmentEntity | null;
  readonly isDefined?: boolean;
};

