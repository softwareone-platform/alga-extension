/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ParameterValueInput } from './ParameterValueInput';
import type { ProductItemExternalIdInput } from './ProductItemExternalIdInput';
import type { RequestObjectLink } from './RequestObjectLink';
import type { Terms } from './Terms';
export type CreateProductItemRequest = {
  product: RequestObjectLink;
  name?: string;
  description?: string;
  externalIds: ProductItemExternalIdInput;
  group: RequestObjectLink;
  unit: RequestObjectLink;
  terms: Terms;
  quantityNotApplicable?: boolean;
  parameters?: Array<ParameterValueInput> | null;
};

