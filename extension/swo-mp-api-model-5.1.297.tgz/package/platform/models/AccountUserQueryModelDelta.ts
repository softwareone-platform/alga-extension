/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountUserQueryModel } from './AccountUserQueryModel';
import type { DeltaNode } from './DeltaNode';
export type AccountUserQueryModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: AccountUserQueryModel | null;
  readonly isDefined?: boolean;
};

