/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AddressOptions } from './AddressOptions';
import type { CheckboxOptions } from './CheckboxOptions';
import type { ChoiceOptions } from './ChoiceOptions';
import type { Constraints } from './Constraints';
import type { ContactOptions } from './ContactOptions';
import type { DataObjectOptions } from './DataObjectOptions';
import type { DateOptions } from './DateOptions';
import type { DropDownOptions } from './DropDownOptions';
import type { EmailOptions } from './EmailOptions';
import type { HeadingOptions } from './HeadingOptions';
import type { MultiLineTextOptions } from './MultiLineTextOptions';
import type { RequestObjectLink } from './RequestObjectLink';
import type { SingleLineTextOptions } from './SingleLineTextOptions';
import type { SubdomainOptions } from './SubdomainOptions';
export type CreateParameterDefinitionRequest = {
  scope: 'Agreement' | 'Item' | 'Request' | 'Subscription' | 'Order' | 'Asset';
  phase: 'Configuration' | 'Order' | 'Fulfillment';
  context?: 'None' | 'Purchase' | 'Change' | 'Configuration' | 'Termination' | null;
  name: string;
  description: string;
  externalId?: string | null;
  displayOrder: number;
  constraints: Constraints;
  type: 'SingleLineText' | 'MultiLineText' | 'Address' | 'Contact' | 'Checkbox' | 'Choice' | 'Subdomain' | 'Heading' | 'DropDown' | 'Email' | 'DataObject' | 'Date';
  options?: (AddressOptions | CheckboxOptions | ChoiceOptions | DataObjectOptions | ContactOptions | DateOptions | DropDownOptions | EmailOptions | HeadingOptions | MultiLineTextOptions | SingleLineTextOptions | SubdomainOptions);
  group?: RequestObjectLink | null;
};

