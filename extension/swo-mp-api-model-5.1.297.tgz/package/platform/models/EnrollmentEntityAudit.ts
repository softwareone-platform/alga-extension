/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type EnrollmentEntityAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  processing?: PlatformObjectEvent | null;
  querying?: PlatformObjectEvent | null;
  completed?: PlatformObjectEvent | null;
  failed?: PlatformObjectEvent | null;
};

