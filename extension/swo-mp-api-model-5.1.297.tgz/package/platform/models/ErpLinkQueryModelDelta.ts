/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { ErpLinkQueryModel } from './ErpLinkQueryModel';
export type ErpLinkQueryModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ErpLinkQueryModel | null;
  readonly isDefined?: boolean;
};

