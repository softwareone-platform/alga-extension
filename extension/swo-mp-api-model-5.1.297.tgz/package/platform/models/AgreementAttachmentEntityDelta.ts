/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AgreementAttachmentEntity } from './AgreementAttachmentEntity';
import type { DeltaNode } from './DeltaNode';
export type AgreementAttachmentEntityDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: AgreementAttachmentEntity | null;
  readonly isDefined?: boolean;
};

