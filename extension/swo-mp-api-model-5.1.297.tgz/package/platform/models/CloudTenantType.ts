/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CloudTenantType = 'AwsDirect' | 'AwsService' | 'Csp365' | 'CspAzure' | 'Ea365' | 'EaAzure' | 'Slm' | 'Virtual';
