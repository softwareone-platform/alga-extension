/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountUserQueryLegacyModel } from './AccountUserQueryLegacyModel';
import type { ListMetadata } from './ListMetadata';
export type AccountUserQueryLegacyModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<AccountUserQueryLegacyModel>;
};

