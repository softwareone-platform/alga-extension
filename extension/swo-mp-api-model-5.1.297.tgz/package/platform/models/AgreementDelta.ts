/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Agreement } from './Agreement';
import type { DeltaNode } from './DeltaNode';
export type AgreementDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Agreement | null;
  readonly isDefined?: boolean;
};

