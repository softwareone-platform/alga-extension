/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DocumentType } from './DocumentType';
export type CreateProductDocumentRequest = {
  /**
   * Json representation of the document
   */
  document?: {
    Name?: string;
    Description?: string;
    Language?: string;
    DocumentType?: DocumentType;
    Url?: string;
    DisplayOrder?: number;
  };
  file?: Blob;
};

