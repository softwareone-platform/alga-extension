/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
import type { QueryModelDateEvent } from './QueryModelDateEvent';
export type AccountUserAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  invited?: PlatformObjectEvent | null;
  joined?: PlatformObjectEvent | null;
  access?: QueryModelDateEvent | null;
};

