/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuthorizationUpdateModel } from './AuthorizationUpdateModel';
import type { DeltaNode } from './DeltaNode';
export type AuthorizationUpdateModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: AuthorizationUpdateModel | null;
  readonly isDefined?: boolean;
};

