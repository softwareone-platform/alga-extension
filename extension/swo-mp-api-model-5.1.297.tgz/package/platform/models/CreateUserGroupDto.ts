/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountDto } from './AccountDto';
import type { BuyerDto } from './BuyerDto';
import type { ExtensionDto } from './ExtensionDto';
import type { ModuleDto } from './ModuleDto';
export type CreateUserGroupDto = {
  name?: string;
  description?: string | null;
  logo?: string | null;
  account?: AccountDto;
  modules?: Array<ModuleDto>;
  buyers?: Array<BuyerDto> | null;
  extensions?: Array<ExtensionDto> | null;
};

