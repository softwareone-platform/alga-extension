/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpLinkQueryModel } from './ErpLinkQueryModel';
import type { ListMetadata } from './ListMetadata';
export type ErpLinkQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<ErpLinkQueryModel>;
};

