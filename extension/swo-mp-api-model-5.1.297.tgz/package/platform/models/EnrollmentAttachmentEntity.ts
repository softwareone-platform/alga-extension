/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EnrollmentEntity } from './EnrollmentEntity';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type EnrollmentAttachmentEntity = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  description?: string;
  type?: string;
  filename?: string;
  size?: number;
  contentType?: string;
  enrollment?: EnrollmentEntity;
};

