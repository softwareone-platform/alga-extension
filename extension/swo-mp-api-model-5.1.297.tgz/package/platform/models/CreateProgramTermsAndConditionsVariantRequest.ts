/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProgramTermsAndConditionsVariantRequest = {
  /**
   * Json representation of the variant
   */
  variant?: {
    Type?: 'Online' | 'File';
    AssetUrl?: string;
    LanguageCode?: string;
    Name?: string;
    Description?: string;
  };
  file?: Blob;
};

