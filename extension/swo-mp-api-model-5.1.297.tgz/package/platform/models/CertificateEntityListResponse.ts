/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CertificateEntity } from './CertificateEntity';
import type { ListMetadata } from './ListMetadata';
export type CertificateEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<CertificateEntity>;
};

