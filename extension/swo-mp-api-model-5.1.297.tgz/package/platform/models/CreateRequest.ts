/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreateParameter } from './CreateParameter';
import type { RequestAssignee } from './RequestAssignee';
import type { RequestFrom } from './RequestFrom';
import type { RequestProduct } from './RequestProduct';
import type { RequestRequester } from './RequestRequester';
import type { RequestTo } from './RequestTo';
export type CreateRequest = {
  externalId?: string | null;
  name: string;
  status: string;
  from: RequestFrom;
  requester?: RequestRequester | null;
  assignee?: RequestAssignee | null;
  to: RequestTo;
  product?: RequestProduct | null;
  parameters?: Array<CreateParameter> | null;
};

