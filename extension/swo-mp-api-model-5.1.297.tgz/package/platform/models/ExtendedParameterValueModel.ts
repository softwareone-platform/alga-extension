/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Constraints } from './Constraints';
import type { ParametrisedMessage } from './ParametrisedMessage';
export type ExtendedParameterValueModel = {
  id?: string;
  value?: any;
  externalId?: string;
  error?: ParametrisedMessage | null;
  constraints?: Constraints | null;
};

