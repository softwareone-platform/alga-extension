/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateTermsAndConditionsRequest = {
  name?: string;
  description?: string | null;
  displayOrder?: number | null;
};

