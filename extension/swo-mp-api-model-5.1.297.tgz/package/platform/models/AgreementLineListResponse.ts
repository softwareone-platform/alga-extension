/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AgreementLine } from './AgreementLine';
import type { ListMetadata } from './ListMetadata';
export type AgreementLineListResponse = {
  $meta?: ListMetadata;
  data?: Array<AgreementLine>;
};

