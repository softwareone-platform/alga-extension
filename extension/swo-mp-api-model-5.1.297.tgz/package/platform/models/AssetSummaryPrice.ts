/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MarkupSourcePrice } from './MarkupSourcePrice';
export type AssetSummaryPrice = {
  currency?: string;
  billingCurrency?: string;
  markup?: number;
  margin?: number;
  defaultMarkupSource?: MarkupSourcePrice | null;
  markupSource?: MarkupSourcePrice | null;
  PPx1?: number | null;
  SPx1?: number | null;
  defaultMarkup?: number | null;
  defaultMargin?: number | null;
};

