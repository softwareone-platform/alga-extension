/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CloudTenantExternalIdsDto = {
  pyraTenantId: string;
  cloudConsumptionId: string;
  providerId?: string | null;
};

