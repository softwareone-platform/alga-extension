/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreatePricingPolicyAttachmentRequest = {
  /**
   * Json representation of the attachment
   */
  attachment?: {
    Name?: string;
    Description?: string;
  };
  file?: Blob;
};

