/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountStatus } from './AccountStatus';
import type { AccountType } from './AccountType';
import type { IdentityType } from './IdentityType';
import type { PlatformIdentity } from './PlatformIdentity';
import type { PlatformObjectEvent } from './PlatformObjectEvent';
import type { UserGroupQueryModel } from './UserGroupQueryModel';
export type AccountUpdateFromFormQueryModel = {
  /**
   * Json representation of the account
   */
  account?: {
    'ExternalIds.PyraTenantId'?: string;
    ExternalId?: string;
    ExternalName?: string;
    'Address.AddressLine1'?: string;
    'Address.AddressLine2'?: string;
    'Address.PostCode'?: string;
    'Address.City'?: string;
    'Address.State'?: string;
    'Address.Country'?: string;
    TechnicalSupportEmail?: string;
    Website?: string;
    Description?: string;
    Groups?: Array<UserGroupQueryModel>;
    'Eligibility.Client'?: boolean;
    'Eligibility.Partner'?: boolean;
    DefaultLanguageCode?: string;
    Type?: AccountType;
    Status?: AccountStatus;
    'Metadata.OmittedProperties'?: Array<string>;
    Name?: string;
    Icon?: string;
    Revision?: number;
    'Audit.Created.At'?: string;
    'Audit.Created.ById'?: string;
    'Audit.Created.By.Type'?: IdentityType;
    'Audit.Created.By.Metadata.OmittedProperties'?: Array<string>;
    'Audit.Created.By.Name'?: string;
    'Audit.Created.By.Icon'?: string;
    'Audit.Created.By.Revision'?: number;
    'Audit.Created.By.Audit.Created'?: PlatformObjectEvent;
    'Audit.Created.By.Audit.Updated.At'?: string;
    'Audit.Created.By.Audit.Updated.ById'?: string;
    'Audit.Created.By.Audit.Updated.By'?: PlatformIdentity;
    'Audit.Created.By.Id'?: string;
    'Audit.Updated.At'?: string;
    'Audit.Updated.ById'?: string;
    'Audit.Updated.By.Type'?: IdentityType;
    'Audit.Updated.By.Metadata.OmittedProperties'?: Array<string>;
    'Audit.Updated.By.Name'?: string;
    'Audit.Updated.By.Icon'?: string;
    'Audit.Updated.By.Revision'?: number;
    'Audit.Updated.By.Audit.Created.At'?: string;
    'Audit.Updated.By.Audit.Created.ById'?: string;
    'Audit.Updated.By.Audit.Created.By'?: PlatformIdentity;
    'Audit.Updated.By.Audit.Updated'?: PlatformObjectEvent;
    'Audit.Updated.By.Id'?: string;
    Id?: string;
  };
  logo?: Blob;
};

