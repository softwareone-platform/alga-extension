/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ItemGroupQueryModel } from './ItemGroupQueryModel';
import type { ListMetadata } from './ListMetadata';
export type ItemGroupQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<ItemGroupQueryModel>;
};

