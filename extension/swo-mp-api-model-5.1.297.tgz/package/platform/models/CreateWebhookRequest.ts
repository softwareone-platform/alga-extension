/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { WebhookType } from './WebhookType';
export type CreateWebhookRequest = {
  type?: WebhookType;
  description?: string | null;
  url: string;
  criteria?: Record<string, string> | null;
  secret?: string | null;
};

