/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DefaultParameterContact } from './DefaultParameterContact';
export type ContactOptions = {
  hintText?: string;
  defaultValue?: DefaultParameterContact;
  phoneMandatory?: boolean;
};

