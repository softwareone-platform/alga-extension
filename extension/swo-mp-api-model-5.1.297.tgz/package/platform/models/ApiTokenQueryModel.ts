/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { ModuleQueryModel } from './ModuleQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
import type { PlatformObjectAuditPlatformExtension } from './PlatformObjectAuditPlatformExtension';
export type ApiTokenQueryModel = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  status?: string;
  description?: string | null;
  lastAccessAt?: string | null;
  token?: string;
  account?: AccountQueryModel;
  modules?: Array<ModuleQueryModel>;
  extensions?: Array<PlatformObjectAuditPlatformExtension> | null;
};

