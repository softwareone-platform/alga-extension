/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountUserQueryModel } from './AccountUserQueryModel';
import type { ListMetadata } from './ListMetadata';
export type AccountUserQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<AccountUserQueryModel>;
};

