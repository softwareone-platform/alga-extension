/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Asset } from './Asset';
import type { ListMetadata } from './ListMetadata';
export type AssetListResponse = {
  $meta?: ListMetadata;
  data?: Array<Asset>;
};

