/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateEnrollmentAttachmentRequest = {
  /**
   * Json representation of the attachment
   */
  attachment?: {
    Name?: string;
    Description?: string;
  };
  file?: Blob;
};

