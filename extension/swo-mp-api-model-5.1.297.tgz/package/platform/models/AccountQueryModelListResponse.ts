/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { ListMetadata } from './ListMetadata';
export type AccountQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<AccountQueryModel>;
};

