/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateItemGroupRequest = {
  name?: string;
  label?: string;
  description?: string | null;
  displayOrder?: number;
  multiple?: boolean;
  required?: boolean;
  default?: boolean;
};

