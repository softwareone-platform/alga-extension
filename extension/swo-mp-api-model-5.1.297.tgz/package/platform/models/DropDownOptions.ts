/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BasicSelectionOption } from './BasicSelectionOption';
export type DropDownOptions = {
  hintText?: string;
  placeholderText?: string | null;
  optionsList?: Array<BasicSelectionOption>;
  description?: string | null;
  defaultValue?: string | null;
};

