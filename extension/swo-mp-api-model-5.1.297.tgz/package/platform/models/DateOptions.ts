/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RangeDateParameter } from './RangeDateParameter';
export type DateOptions = {
  hintText?: string;
  dateRange?: boolean;
  minAvailableDate?: string | null;
  maxAvailableDate?: string | null;
  defaultValue?: (RangeDateParameter | string) | null;
};

