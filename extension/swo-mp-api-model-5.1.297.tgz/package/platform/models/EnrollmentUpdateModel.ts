/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ParametrisedMessage } from './ParametrisedMessage';
import type { RequestObjectLink } from './RequestObjectLink';
import type { UpdateEnrollmentParameterBag } from './UpdateEnrollmentParameterBag';
export type EnrollmentUpdateModel = {
  program?: RequestObjectLink;
  statusNotes?: ParametrisedMessage;
  notes?: string | null;
  assignee?: RequestObjectLink | null;
  error?: ParametrisedMessage | null;
  parameters?: UpdateEnrollmentParameterBag;
  template?: RequestObjectLink;
};

