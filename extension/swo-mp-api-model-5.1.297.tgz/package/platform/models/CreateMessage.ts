/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { RequestMessageVisibility } from './RequestMessageVisibility';
export type CreateMessage = {
  visibility: RequestMessageVisibility;
  content: string;
};

