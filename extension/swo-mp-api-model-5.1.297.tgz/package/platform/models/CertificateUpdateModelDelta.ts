/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CertificateUpdateModel } from './CertificateUpdateModel';
import type { DeltaNode } from './DeltaNode';
export type CertificateUpdateModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: CertificateUpdateModel | null;
  readonly isDefined?: boolean;
};

