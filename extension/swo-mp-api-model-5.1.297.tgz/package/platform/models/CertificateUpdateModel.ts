/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CertificateExternalIds } from './CertificateExternalIds';
import type { RequestObjectLink } from './RequestObjectLink';
import type { UpdateCertificateParameterBag } from './UpdateCertificateParameterBag';
export type CertificateUpdateModel = {
  parameters?: UpdateCertificateParameterBag;
  template?: RequestObjectLink;
  expirationDate?: string;
  externalIds?: CertificateExternalIds;
  name?: string | null;
};

