/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DataObjectType } from './DataObjectType';
export type DataObjectOptions = {
  hintText?: string;
  defaultValue?: string | null;
  objectType?: DataObjectType;
};

