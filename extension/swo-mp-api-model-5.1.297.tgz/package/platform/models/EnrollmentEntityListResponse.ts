/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EnrollmentEntity } from './EnrollmentEntity';
import type { ListMetadata } from './ListMetadata';
export type EnrollmentEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<EnrollmentEntity>;
};

