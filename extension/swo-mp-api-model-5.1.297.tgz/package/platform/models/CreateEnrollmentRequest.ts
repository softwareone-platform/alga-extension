/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ProgramParameterValueBagInput } from './ProgramParameterValueBagInput';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateEnrollmentRequest = {
  certificate?: RequestObjectLink | null;
  program?: RequestObjectLink | null;
  buyer?: RequestObjectLink | null;
  licensee?: RequestObjectLink | null;
  client?: RequestObjectLink | null;
  name?: string | null;
  parameters?: ProgramParameterValueBagInput | null;
};

