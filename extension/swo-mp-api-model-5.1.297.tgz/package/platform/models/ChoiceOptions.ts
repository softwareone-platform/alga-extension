/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SelectionOption } from './SelectionOption';
export type ChoiceOptions = {
  hintText?: string;
  optionsList?: Array<SelectionOption>;
  defaultValue?: string | null;
};

