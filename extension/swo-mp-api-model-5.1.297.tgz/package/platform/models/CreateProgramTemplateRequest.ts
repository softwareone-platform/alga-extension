/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProgramTemplateRequest = {
  name: string;
  type?: 'EnrollmentProcessing' | 'EnrollmentQuerying' | 'EnrollmentCompleted';
  default?: boolean;
  content: string;
};

