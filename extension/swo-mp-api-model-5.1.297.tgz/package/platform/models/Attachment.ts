/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
import type { RequestQueryModel } from './RequestQueryModel';
export type Attachment = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  type?: string;
  description?: string;
  filename?: string;
  size?: number;
  contentType?: string;
  request?: RequestQueryModel;
};

