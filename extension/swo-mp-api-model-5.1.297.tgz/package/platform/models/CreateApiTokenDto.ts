/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountDto } from './AccountDto';
import type { ExtensionDto } from './ExtensionDto';
import type { ModuleDto } from './ModuleDto';
export type CreateApiTokenDto = {
  account?: AccountDto;
  name?: string;
  icon?: string | null;
  description?: string | null;
  modules?: Array<ModuleDto> | null;
  extensions?: Array<ExtensionDto> | null;
};

