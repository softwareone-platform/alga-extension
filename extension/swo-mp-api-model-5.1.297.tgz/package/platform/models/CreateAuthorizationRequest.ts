/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuthorizationEligibility } from './AuthorizationEligibility';
import type { AuthorizationExternalIdInput } from './AuthorizationExternalIdInput';
import type { JournalInput } from './JournalInput';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateAuthorizationRequest = {
  name?: string;
  externalIds?: AuthorizationExternalIdInput | null;
  currency?: string;
  notes?: string | null;
  product: RequestObjectLink;
  owner: RequestObjectLink;
  journal: JournalInput;
  eligibility: AuthorizationEligibility;
  settings?: string | null;
};

