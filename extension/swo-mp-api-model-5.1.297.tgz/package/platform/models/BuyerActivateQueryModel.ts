/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { AddressQueryModel } from './AddressQueryModel';
import type { BuyerExternalIdsQueryModel } from './BuyerExternalIdsQueryModel';
import type { BuyerQueryModelAudit } from './BuyerQueryModelAudit';
import type { BuyerStatus } from './BuyerStatus';
import type { ParametrisedMessage } from './ParametrisedMessage';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { SellerQueryModel } from './SellerQueryModel';
export type BuyerActivateQueryModel = {
  id?: string;
  audit?: BuyerQueryModelAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  externalIds: BuyerExternalIdsQueryModel;
  status?: BuyerStatus | null;
  address?: AddressQueryModel | null;
  taxId?: string | null;
  account: AccountQueryModel;
  errors?: Array<ParametrisedMessage> | null;
  sellers?: Array<SellerQueryModel> | null;
};

