/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { EnrollmentAttachmentEntity } from './EnrollmentAttachmentEntity';
import type { ListMetadata } from './ListMetadata';
export type EnrollmentAttachmentEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<EnrollmentAttachmentEntity>;
};

