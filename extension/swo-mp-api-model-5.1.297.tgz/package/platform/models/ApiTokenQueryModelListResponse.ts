/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ApiTokenQueryModel } from './ApiTokenQueryModel';
import type { ListMetadata } from './ListMetadata';
export type ApiTokenQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<ApiTokenQueryModel>;
};

