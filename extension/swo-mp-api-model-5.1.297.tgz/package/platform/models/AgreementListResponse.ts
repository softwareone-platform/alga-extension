/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Agreement } from './Agreement';
import type { ListMetadata } from './ListMetadata';
export type AgreementListResponse = {
  $meta?: ListMetadata;
  data?: Array<Agreement>;
};

