/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateParameter = {
  parameterDefinitionId: string;
  value: string;
};

