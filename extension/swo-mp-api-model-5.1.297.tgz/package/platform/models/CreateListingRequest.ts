/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ListingEligibility } from './ListingEligibility';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreateListingRequest = {
  primary?: boolean;
  notes?: string | null;
  product: RequestObjectLink;
  authorization: RequestObjectLink;
  seller: RequestObjectLink;
  priceList: RequestObjectLink;
  eligibility: ListingEligibility;
};

