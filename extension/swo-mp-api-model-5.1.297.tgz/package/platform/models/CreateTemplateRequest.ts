/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateTemplateRequest = {
  name: string;
  type?: 'OrderProcessing' | 'OrderQuerying' | 'OrderCompleted' | 'RequestProcessing' | 'Subscription' | 'Asset';
  default?: boolean | null;
  content: string;
};

