/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuthorizationEligibility } from './AuthorizationEligibility';
import type { AuthorizationExternalIdBag } from './AuthorizationExternalIdBag';
import type { JournalInput } from './JournalInput';
export type AuthorizationUpdateModel = {
  name?: string;
  externalIds?: AuthorizationExternalIdBag | null;
  currency?: string;
  notes?: string | null;
  journal?: JournalInput;
  eligibility?: AuthorizationEligibility;
  settings?: string | null;
};

