/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
export type DecimalDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: number;
  readonly isDefined?: boolean;
};

