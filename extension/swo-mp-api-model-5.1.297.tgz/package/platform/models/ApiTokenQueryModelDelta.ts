/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ApiTokenQueryModel } from './ApiTokenQueryModel';
import type { DeltaNode } from './DeltaNode';
export type ApiTokenQueryModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: ApiTokenQueryModel | null;
  readonly isDefined?: boolean;
};

