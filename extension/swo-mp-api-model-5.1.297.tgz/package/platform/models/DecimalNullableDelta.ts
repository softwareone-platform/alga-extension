/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
export type DecimalNullableDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: number | null;
  readonly isDefined?: boolean;
};

