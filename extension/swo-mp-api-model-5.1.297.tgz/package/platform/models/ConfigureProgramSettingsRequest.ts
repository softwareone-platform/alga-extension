/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ProgramPreValidationInput } from './ProgramPreValidationInput';
import type { TerminateOnExpiration } from './TerminateOnExpiration';
export type ConfigureProgramSettingsRequest = {
  newCertificateAutoapprove?: boolean | null;
  programEnrollment?: boolean | null;
  programLink?: boolean | null;
  terminateOnExpiration?: TerminateOnExpiration | null;
  preValidation?: ProgramPreValidationInput | null;
};

