/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Agreement } from './Agreement';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
export type AgreementAttachmentEntity = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  type?: string;
  description?: string;
  filename?: string | null;
  size?: number | null;
  contentType?: string;
  orderId?: string;
  licenseKey?: string;
  agreement?: Agreement;
};

