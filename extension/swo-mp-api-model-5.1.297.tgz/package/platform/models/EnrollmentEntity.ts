/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { CertificateEntity } from './CertificateEntity';
import type { EnrollmentEntityAudit } from './EnrollmentEntityAudit';
import type { EnrollmentStatus } from './EnrollmentStatus';
import type { EnrollmentType } from './EnrollmentType';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { ParametrisedMessage } from './ParametrisedMessage';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProgramApplicableTo } from './ProgramApplicableTo';
import type { ProgramEligibility } from './ProgramEligibility';
import type { ProgramEntity } from './ProgramEntity';
import type { ProgramParameterBag } from './ProgramParameterBag';
import type { ProgramTemplateEntity } from './ProgramTemplateEntity';
import type { UserQueryModel } from './UserQueryModel';
export type EnrollmentEntity = {
  id?: string;
  audit?: EnrollmentEntityAudit;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  name?: string;
  certificate?: CertificateEntity;
  program?: ProgramEntity;
  applicableTo?: ProgramApplicableTo;
  type?: EnrollmentType;
  buyer?: BuyerQueryModel | null;
  licensee?: LicenseeQueryModel | null;
  eligibility?: ProgramEligibility;
  status?: EnrollmentStatus;
  notes?: string | null;
  statusNotes?: ParametrisedMessage | null;
  assignee?: UserQueryModel | null;
  parameters?: ProgramParameterBag;
  error?: ParametrisedMessage | null;
  template?: ProgramTemplateEntity | null;
};

