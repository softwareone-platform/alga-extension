/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DefaultParameterEmail } from './DefaultParameterEmail';
export type EmailOptions = {
  placeholderText?: string;
  hintText?: string;
  defaultValue?: DefaultParameterEmail;
};

