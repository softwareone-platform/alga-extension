/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ParametrisedMessage } from './ParametrisedMessage';
export type FailEnrollmentRequest = {
  statusNotes: ParametrisedMessage;
};

