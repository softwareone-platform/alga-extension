/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CloudTenantExternalIdsQueryModel = {
  cloudConsumptionId?: string;
  providerId?: string | null;
  pyraTenantId?: string;
};

