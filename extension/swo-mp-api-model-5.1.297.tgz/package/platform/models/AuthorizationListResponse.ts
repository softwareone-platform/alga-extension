/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Authorization } from './Authorization';
import type { ListMetadata } from './ListMetadata';
export type AuthorizationListResponse = {
  $meta?: ListMetadata;
  data?: Array<Authorization>;
};

