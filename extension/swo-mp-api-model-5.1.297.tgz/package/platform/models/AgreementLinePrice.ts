/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MarkupSourcePrice } from './MarkupSourcePrice';
export type AgreementLinePrice = {
  currency?: string;
  billingCurrency?: string;
  markup?: number;
  margin?: number;
  defaultMarkupSource?: MarkupSourcePrice | null;
  markupSource?: MarkupSourcePrice | null;
  unitSP?: number | null;
  unitPP?: number | null;
  PPx1?: number | null;
  SPx1?: number | null;
  SPxY?: number | null;
  SPxM?: number | null;
  PPxY?: number | null;
  PPxM?: number | null;
};

