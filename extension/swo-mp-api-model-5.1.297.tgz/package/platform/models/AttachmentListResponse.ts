/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Attachment } from './Attachment';
import type { ListMetadata } from './ListMetadata';
export type AttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<Attachment>;
};

