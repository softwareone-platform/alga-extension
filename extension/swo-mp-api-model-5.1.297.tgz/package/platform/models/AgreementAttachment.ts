/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AttachmentType } from './AttachmentType';
export type AgreementAttachment = {
  /**
   * Json representation of the attachment
   */
  attachment?: {
    Name?: string;
    Description?: string;
    OrderId?: string;
    Type?: AttachmentType;
    LicenseKey?: string;
  };
  file?: Blob;
};

