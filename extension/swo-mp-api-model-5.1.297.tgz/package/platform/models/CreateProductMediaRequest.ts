/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MediaType } from './MediaType';
export type CreateProductMediaRequest = {
  /**
   * Json representation of the media
   */
  media?: {
    Name?: string;
    Description?: string;
    MediaType?: MediaType;
    Url?: string;
    DisplayOrder?: number;
  };
  file?: Blob;
};

