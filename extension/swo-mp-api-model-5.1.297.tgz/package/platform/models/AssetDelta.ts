/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Asset } from './Asset';
import type { DeltaNode } from './DeltaNode';
export type AssetDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Asset | null;
  readonly isDefined?: boolean;
};

