/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
export type ConstraintTypeBooleanNullableDictionaryDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: {
    Required?: boolean;
    Hidden?: boolean;
    ReadOnly?: boolean;
  } | null;
  readonly isDefined?: boolean;
};

