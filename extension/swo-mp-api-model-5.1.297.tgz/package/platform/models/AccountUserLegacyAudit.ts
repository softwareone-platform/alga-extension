/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
import type { QueryModelDateEvent } from './QueryModelDateEvent';
export type AccountUserLegacyAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  invitationAcceptedAt?: string | null;
  access?: QueryModelDateEvent | null;
  joined?: QueryModelDateEvent | null;
};

