/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PriceListExternalIdInput } from './PriceListExternalIdInput';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreatePriceListRequest = {
  currency?: string;
  precision: number;
  defaultMarkup?: number | null;
  defaultMargin?: number | null;
  notes?: string | null;
  externalIds?: PriceListExternalIdInput | null;
  product: RequestObjectLink;
};

