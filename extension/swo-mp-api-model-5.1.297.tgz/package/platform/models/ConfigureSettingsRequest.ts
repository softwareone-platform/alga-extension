/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PreValidationInput } from './PreValidationInput';
import type { ProductRequestsInput } from './ProductRequestsInput';
import type { ProductSplitBillingRequestsInput } from './ProductSplitBillingRequestsInput';
import type { SubscriptionCessationInput } from './SubscriptionCessationInput';
export type ConfigureSettingsRequest = {
  productOrdering?: boolean | null;
  productRequests?: ProductRequestsInput | null;
  itemSelection?: boolean | null;
  orderQueueChanges?: boolean | null;
  preValidation?: PreValidationInput | null;
  splitBilling?: ProductSplitBillingRequestsInput | null;
  sendCostToErp?: boolean | null;
  subscriptionCessation?: SubscriptionCessationInput | null;
};

