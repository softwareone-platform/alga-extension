/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { EnrollmentUpdateModel } from './EnrollmentUpdateModel';
export type EnrollmentUpdateModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: EnrollmentUpdateModel | null;
  readonly isDefined?: boolean;
};

