/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type InvitationQueryModel = {
  url?: string | null;
  notes?: string | null;
  status?: string;
};

