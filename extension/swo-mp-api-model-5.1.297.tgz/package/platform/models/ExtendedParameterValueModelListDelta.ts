/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { ExtendedParameterValueModel } from './ExtendedParameterValueModel';
export type ExtendedParameterValueModelListDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: Array<ExtendedParameterValueModel> | null;
  readonly isDefined?: boolean;
};

