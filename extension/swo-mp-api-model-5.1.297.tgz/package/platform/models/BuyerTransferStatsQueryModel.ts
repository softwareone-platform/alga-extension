/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BuyerTransferStatsQueryModel = {
  licenseeCount?: number;
  orderCount?: number;
  subscriptionCount?: number;
  userCount?: number;
  userGroupCount?: number;
  agreementCount?: number;
};

