/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountExternalIdsQueryModel } from './AccountExternalIdsQueryModel';
import type { AccountStatus } from './AccountStatus';
import type { AccountType } from './AccountType';
import type { AddressQueryModel } from './AddressQueryModel';
import type { EligibilityQueryModel } from './EligibilityQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
import type { UserGroupQueryModel } from './UserGroupQueryModel';
export type AccountValidateQueryModel = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  type?: AccountType | null;
  status?: AccountStatus | null;
  externalIds?: AccountExternalIdsQueryModel | null;
  externalId?: string | null;
  externalName?: string | null;
  address?: AddressQueryModel | null;
  technicalSupportEmail?: string | null;
  website?: string | null;
  description?: string | null;
  groups?: Array<UserGroupQueryModel> | null;
  eligibility?: EligibilityQueryModel | null;
  defaultLanguageCode?: string | null;
};

