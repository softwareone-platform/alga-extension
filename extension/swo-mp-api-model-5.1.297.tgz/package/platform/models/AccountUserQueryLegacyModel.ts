/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { AccountUserLegacyAudit } from './AccountUserLegacyAudit';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { InvitationQueryModel } from './InvitationQueryModel';
import type { ModuleQueryModel } from './ModuleQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { UserGroupQueryModel } from './UserGroupQueryModel';
import type { UserQueryModel } from './UserQueryModel';
export type AccountUserQueryLegacyModel = {
  id?: string;
  audit?: AccountUserLegacyAudit;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  user?: UserQueryModel;
  groups?: Array<UserGroupQueryModel>;
  buyers?: Array<BuyerQueryModel> | null;
  modules?: Array<ModuleQueryModel>;
  account?: AccountQueryModel;
  invitation?: InvitationQueryModel;
  lastLoginAt?: string | null;
};

