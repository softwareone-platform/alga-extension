/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CloudTenantQueryModel } from './CloudTenantQueryModel';
import type { ListMetadata } from './ListMetadata';
export type CloudTenantQueryModelListResponse = {
  $meta?: ListMetadata;
  data?: Array<CloudTenantQueryModel>;
};

