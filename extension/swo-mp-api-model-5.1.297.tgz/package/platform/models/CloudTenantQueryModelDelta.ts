/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CloudTenantQueryModel } from './CloudTenantQueryModel';
import type { DeltaNode } from './DeltaNode';
export type CloudTenantQueryModelDelta = {
  node?: DeltaNode | null;
  path?: string;
  readonly data?: CloudTenantQueryModel | null;
  readonly isDefined?: boolean;
};

