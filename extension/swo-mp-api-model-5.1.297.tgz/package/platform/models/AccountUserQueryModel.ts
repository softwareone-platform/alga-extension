/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { AccountUserAudit } from './AccountUserAudit';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { InvitationQueryModel } from './InvitationQueryModel';
import type { ModuleQueryModel } from './ModuleQueryModel';
import type { PhoneNumberQueryModel } from './PhoneNumberQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { UserGroupQueryModel } from './UserGroupQueryModel';
import type { UserQueryModel } from './UserQueryModel';
import type { UserSettingsQueryModel } from './UserSettingsQueryModel';
export type AccountUserQueryModel = {
  id?: string;
  audit?: AccountUserAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  /**
   * @deprecated
   */
  user?: UserQueryModel;
  email?: string;
  status?: string;
  phone?: PhoneNumberQueryModel | null;
  firstName?: string;
  lastName?: string;
  settings?: UserSettingsQueryModel | null;
  groups?: Array<UserGroupQueryModel>;
  buyers?: Array<BuyerQueryModel> | null;
  modules?: Array<ModuleQueryModel>;
  account?: AccountQueryModel;
  invitation?: InvitationQueryModel;
};

