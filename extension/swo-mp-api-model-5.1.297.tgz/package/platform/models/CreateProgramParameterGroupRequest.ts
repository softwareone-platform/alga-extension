/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProgramParameterGroupRequest = {
  name?: string;
  label?: string;
  description?: string | null;
  displayOrder?: number;
  default?: boolean;
};

