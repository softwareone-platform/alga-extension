/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PricingPolicyEligibility } from './PricingPolicyEligibility';
import type { PricingPolicyExternalIdInput } from './PricingPolicyExternalIdInput';
import type { RequestObjectLink } from './RequestObjectLink';
export type CreatePricingPolicyRequest = {
  name?: string;
  externalIds?: PricingPolicyExternalIdInput | null;
  client?: RequestObjectLink;
  eligibility: PricingPolicyEligibility;
  markup?: number | null;
  margin?: number | null;
  notes?: string | null;
  products?: Array<RequestObjectLink> | null;
};

