/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DocumentId } from './DocumentId';
import type { DocumentStatus } from './DocumentStatus';
import type { DomainEvent } from './DomainEvent';
import type { FileId } from './FileId';
import type { IBusinessIdentifier } from './IBusinessIdentifier';
export type Document = {
  readonly domainEvents?: Array<DomainEvent>;
  readonly markedForDelete?: boolean;
  readonly markedForUpdate?: boolean;
  readonly documentId?: DocumentId;
  readonly fileId?: FileId;
  readonly url?: string | null;
  readonly id?: IBusinessIdentifier;
  readonly language?: string | null;
  readonly status?: DocumentStatus;
  isDeleted?: boolean;
  readonly revision?: number;
  readonly useDeleteStatus?: boolean;
};

