/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DocumentId = {
  readonly value?: string;
  readonly postfixNumber?: number;
};

