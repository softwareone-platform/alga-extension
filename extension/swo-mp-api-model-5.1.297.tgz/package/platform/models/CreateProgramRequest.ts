/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateProgramRequest = {
  /**
   * Json representation of the Program
   */
  Program?: {
    Name?: string;
    ShortDescription?: string;
    LongDescription?: string;
    Website?: string;
    ApplicableTo?: 'Buyer' | 'Licensee';
    'Eligibility.Client'?: boolean;
    'Eligibility.Partner'?: boolean;
  };
  icon?: Blob;
};

