/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Exchange Entity Audit properties bag
 */
export type ExchangeAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  /**
   * Delete event details
   */
  deleted?: PlatformObjectEvent | null;
};

