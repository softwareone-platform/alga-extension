/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CurrencyStatus } from './CurrencyStatus';
import type { DeltaNode } from './DeltaNode';
import type { IdentityType } from './IdentityType';
import type { PlatformIdentity } from './PlatformIdentity';
export type CurrencyWithIconModel = {
  /**
   * Json representation of the currency
   */
  currency?: {
    'Currency.Node.Name'?: string;
    'Currency.Node.Children'?: Array<DeltaNode>;
    'Currency.Path'?: string;
    /**
     * The unique identifier of the currency.
     */
    'Currency.Data.Id'?: string;
    /**
     * The name of the currency.
     */
    'Currency.Data.Name'?: string;
    /**
     * The ISO code of currency
     */
    'Currency.Data.Code'?: string;
    /**
     * Precision of the currency
     */
    'Currency.Data.Precision'?: number;
    /**
     * Number of sellers using currency
     */
    'Currency.Data.Statistics.SellerCount'?: number;
    /**
     * Number of pairs
     */
    'Currency.Data.Statistics.PairsCount'?: number;
    /**
     * The current status of the currency.
     */
    'Currency.Data.Status'?: CurrencyStatus;
    'Currency.Data.Metadata.OmittedProperties'?: Array<string>;
    'Currency.Data.Icon'?: string;
    'Currency.Data.Revision'?: number;
    'Currency.Data.Audit.Deleted.At'?: string;
    'Currency.Data.Audit.Deleted.ById'?: string;
    'Currency.Data.Audit.Deleted.By.Type'?: IdentityType;
    'Currency.Data.Audit.Deleted.By.Metadata.OmittedProperties'?: Array<string>;
    'Currency.Data.Audit.Deleted.By.Name'?: string;
    'Currency.Data.Audit.Deleted.By.Icon'?: string;
    'Currency.Data.Audit.Deleted.By.Revision'?: number;
    'Currency.Data.Audit.Deleted.By.Audit.Created.At'?: string;
    'Currency.Data.Audit.Deleted.By.Audit.Created.ById'?: string;
    'Currency.Data.Audit.Deleted.By.Audit.Created.By'?: PlatformIdentity;
    'Currency.Data.Audit.Deleted.By.Audit.Updated.At'?: string;
    'Currency.Data.Audit.Deleted.By.Audit.Updated.ById'?: string;
    'Currency.Data.Audit.Deleted.By.Audit.Updated.By'?: PlatformIdentity;
    'Currency.Data.Audit.Deleted.By.Id'?: string;
    'Currency.Data.Audit.Created.At'?: string;
    'Currency.Data.Audit.Created.ById'?: string;
    'Currency.Data.Audit.Created.By.Type'?: IdentityType;
    'Currency.Data.Audit.Created.By.Metadata.OmittedProperties'?: Array<string>;
    'Currency.Data.Audit.Created.By.Name'?: string;
    'Currency.Data.Audit.Created.By.Icon'?: string;
    'Currency.Data.Audit.Created.By.Revision'?: number;
    'Currency.Data.Audit.Created.By.Audit.Created.At'?: string;
    'Currency.Data.Audit.Created.By.Audit.Created.ById'?: string;
    'Currency.Data.Audit.Created.By.Audit.Created.By'?: PlatformIdentity;
    'Currency.Data.Audit.Created.By.Audit.Updated.At'?: string;
    'Currency.Data.Audit.Created.By.Audit.Updated.ById'?: string;
    'Currency.Data.Audit.Created.By.Audit.Updated.By'?: PlatformIdentity;
    'Currency.Data.Audit.Created.By.Id'?: string;
    'Currency.Data.Audit.Updated.At'?: string;
    'Currency.Data.Audit.Updated.ById'?: string;
    'Currency.Data.Audit.Updated.By.Type'?: IdentityType;
    'Currency.Data.Audit.Updated.By.Metadata.OmittedProperties'?: Array<string>;
    'Currency.Data.Audit.Updated.By.Name'?: string;
    'Currency.Data.Audit.Updated.By.Icon'?: string;
    'Currency.Data.Audit.Updated.By.Revision'?: number;
    'Currency.Data.Audit.Updated.By.Audit.Created.At'?: string;
    'Currency.Data.Audit.Updated.By.Audit.Created.ById'?: string;
    'Currency.Data.Audit.Updated.By.Audit.Created.By'?: PlatformIdentity;
    'Currency.Data.Audit.Updated.By.Audit.Updated.At'?: string;
    'Currency.Data.Audit.Updated.By.Audit.Updated.ById'?: string;
    'Currency.Data.Audit.Updated.By.Audit.Updated.By'?: PlatformIdentity;
    'Currency.Data.Audit.Updated.By.Id'?: string;
    'Currency.IsDefined'?: boolean;
  };
  /**
   * Icon for the new currency
   */
  icon?: Blob;
};

