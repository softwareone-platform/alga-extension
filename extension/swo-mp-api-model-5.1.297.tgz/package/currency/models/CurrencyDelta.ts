/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Currency } from './Currency';
import type { DeltaNode } from './DeltaNode';
export type CurrencyDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents currency in exchange module.
   */
  readonly data?: Currency | null;
  readonly isDefined?: boolean;
};

