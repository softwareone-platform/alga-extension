/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CurrencyStatistics } from './CurrencyStatistics';
import type { CurrencyStatus } from './CurrencyStatus';
import type { ExchangeAudit } from './ExchangeAudit';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
/**
 * Represents currency in exchange module.
 */
export type Currency = {
  /**
   * Exchange Entity Audit properties bag
   */
  audit?: ExchangeAudit;
  $meta?: PlatformEntityMetadata | null;
  icon?: string | null;
  revision?: number;
  /**
   * The unique identifier of the currency.
   */
  id?: string;
  /**
   * The name of the currency.
   */
  name?: string;
  /**
   * The ISO code of currency
   */
  code?: string;
  /**
   * Precision of the currency
   */
  precision?: number;
  /**
   * Currency statistics
   */
  statistics?: CurrencyStatistics;
  /**
   * The current status of the currency.
   */
  status?: CurrencyStatus;
};

