/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Currency status enumeration
 */
export type CurrencyStatus = 'Active' | 'Deleted';
