/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Currency usage statistics
 */
export type CurrencyStatistics = {
  /**
   * Number of sellers using currency
   */
  sellerCount?: number;
  /**
   * Number of pairs
   */
  pairsCount?: number;
};

