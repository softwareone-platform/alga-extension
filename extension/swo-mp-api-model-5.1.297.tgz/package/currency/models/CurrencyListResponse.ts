/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Currency } from './Currency';
import type { ListMetadata } from './ListMetadata';
export type CurrencyListResponse = {
  $meta?: ListMetadata;
  data?: Array<Currency>;
};

