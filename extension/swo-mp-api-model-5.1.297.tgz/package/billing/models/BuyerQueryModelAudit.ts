/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type BuyerQueryModelAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  activated?: PlatformObjectEvent | null;
  unassigned?: PlatformObjectEvent | null;
  disabled?: PlatformObjectEvent | null;
};

