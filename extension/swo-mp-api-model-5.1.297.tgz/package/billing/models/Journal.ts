/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Authorization } from './Authorization';
import type { BillingEntityError } from './BillingEntityError';
import type { BillingExternalIds } from './BillingExternalIds';
import type { JournalAuditBag } from './JournalAuditBag';
import type { JournalPriceSummary } from './JournalPriceSummary';
import type { JournalStatus } from './JournalStatus';
import type { JournalUploadSummary } from './JournalUploadSummary';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformIdentity } from './PlatformIdentity';
import type { ProcessingSummary } from './ProcessingSummary';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
/**
 * Represents a journal entry in the billing system.
 */
export type Journal = {
  /**
   * Represents a container for audit-related events for a journal
   */
  audit?: JournalAuditBag;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * The unique identifier of the journal entry.
   */
  id?: string;
  /**
   * Name of the journal.
   */
  name?: string;
  /**
   * A description of the journal entry.
   */
  description?: string;
  /**
   * External identifiers associated with the journal entry.
   */
  externalIds?: BillingExternalIds;
  /**
   * Additional notes or comments about the journal entry.
   */
  notes?: string | null;
  /**
   * The current status of the journal entry.
   */
  status?: JournalStatus;
  /**
   * The vendor associated with the journal entry.
   */
  vendor?: AccountQueryModel;
  /**
   * The owner of the journal entry.
   */
  owner?: SellerQueryModel;
  /**
   * The product associated with the journal entry.
   */
  product?: ProductQueryModel;
  /**
   * Authorization details associated with the journal entry.
   */
  authorization?: Authorization;
  /**
   * The due date for the journal entry.
   */
  dueDate?: string;
  /**
   * The user assigned to the journal entry, if applicable.
   */
  assignee?: PlatformIdentity | null;
  /**
   * Pricing details associated with the journal entry.
   */
  price?: JournalPriceSummary;
  /**
   * Upload summary details for the journal entry, visible to vendors or operations.
   */
  upload?: JournalUploadSummary;
  /**
   * Processing status and related details for the journal entry, visible to operations.
   */
  processing?: ProcessingSummary;
  /**
   * Error details associated with the journal entry, if any.
   */
  error?: BillingEntityError | null;
};

