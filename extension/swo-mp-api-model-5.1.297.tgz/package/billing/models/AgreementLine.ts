/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Agreement } from './Agreement';
import type { AgreementLineAuditEntity } from './AgreementLineAuditEntity';
import type { AgreementLinePrice } from './AgreementLinePrice';
import type { AgreementLineStatus } from './AgreementLineStatus';
import type { Asset } from './Asset';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { Order } from './Order';
import type { ProductItemEntity } from './ProductItemEntity';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
import type { Subscription } from './Subscription';
export type AgreementLine = {
  id?: string;
  audit?: AgreementLineAuditEntity;
  quantity?: number;
  item?: ProductItemEntity;
  price?: AgreementLinePrice;
  order?: Order | null;
  status?: AgreementLineStatus;
  subscription?: Subscription;
  asset?: Asset;
  agreement?: Agreement;
  client?: AccountQueryModel;
  vendor?: AccountQueryModel;
  buyer?: BuyerQueryModel;
  seller?: SellerQueryModel;
  product?: ProductQueryModel;
};

