/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { BillingEntityError } from './BillingEntityError';
import type { BillingExternalIds } from './BillingExternalIds';
import type { CustomLedgerAuditBag } from './CustomLedgerAuditBag';
import type { CustomLedgerPriceSummary } from './CustomLedgerPriceSummary';
import type { CustomLedgerStatus } from './CustomLedgerStatus';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformIdentity } from './PlatformIdentity';
import type { ProcessingSummary } from './ProcessingSummary';
import type { SellerQueryModel } from './SellerQueryModel';
/**
 * Represents a custom ledger in the billing system.
 */
export type CustomLedger = {
  /**
   * Represents a container for audit-related events for a custom ledger
   */
  audit?: CustomLedgerAuditBag;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * The unique identifier of the custom ledger.
   */
  id?: string;
  /**
   * Name of the custom ledger.
   */
  name?: string;
  /**
   * External identifiers associated with the custom ledger.
   */
  externalIds?: BillingExternalIds;
  /**
   * The seller associated with the custom ledger.
   */
  seller?: SellerQueryModel;
  /**
   * The vendor associated with the custom ledger.
   */
  vendor?: AccountQueryModel;
  /**
   * The start date of the billing period for the custom ledger.
   */
  billingStartDate?: string;
  /**
   * The end date of the billing period for the custom ledger.
   */
  billingEndDate?: string;
  /**
   * Additional notes or comments about the custom ledger.
   */
  notes?: string | null;
  /**
   * The current status of the custom ledger.
   */
  status?: CustomLedgerStatus;
  /**
   * The user assigned to the custom ledger, if applicable.
   */
  assignee?: PlatformIdentity | null;
  /**
   * Pricing details associated with the custom ledger.
   */
  price?: CustomLedgerPriceSummary;
  /**
   * Processing status and related details for the custom ledger, visible to operations.
   */
  processing?: ProcessingSummary;
  /**
   * Error details associated with the custom ledger, if any.
   */
  error?: BillingEntityError | null;
};

