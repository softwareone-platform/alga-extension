/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Represents a container for audit-related events for a journal
 */
export type JournalAuditBag = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Draft" status.
   */
  draft?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Deleted" status.
   */
  deleted?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Error" status.
   */
  error?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Validating" status.
   */
  validating?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Validated" status.
   */
  validated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Review" status.
   */
  review?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Enquiring" status.
   */
  enquiring?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Generating" status.
   */
  generating?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Generated" status.
   */
  generated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Accepted" status.
   */
  accepted?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the journal reached the "Completed" status.
   */
  completed?: PlatformObjectEvent | null;
};

