/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents a description of a charge.
 */
export type ChargeDescription = {
  /**
   * The first value of the description, if applicable.
   */
  value1?: string | null;
  /**
   * The second value of the description, if applicable.
   */
  value2?: string | null;
};

