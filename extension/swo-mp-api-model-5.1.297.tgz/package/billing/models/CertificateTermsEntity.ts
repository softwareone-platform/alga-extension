/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ExtendedIdentityQueryModel } from './ExtendedIdentityQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProgramEntity } from './ProgramEntity';
import type { ProgramTermsAndConditionsEntityAudit } from './ProgramTermsAndConditionsEntityAudit';
export type CertificateTermsEntity = {
  id?: string;
  audit?: ProgramTermsAndConditionsEntityAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  description?: string | null;
  displayOrder?: number;
  status?: string;
  program?: ProgramEntity;
  accepted?: string | null;
  acceptedBy?: ExtendedIdentityQueryModel;
};

