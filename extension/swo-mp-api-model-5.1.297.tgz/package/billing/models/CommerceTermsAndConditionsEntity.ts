/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ExtendedIdentityQueryModel } from './ExtendedIdentityQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProductQueryModel } from './ProductQueryModel';
import type { TermsAndConditionsQueryModelAudit } from './TermsAndConditionsQueryModelAudit';
export type CommerceTermsAndConditionsEntity = {
  id?: string;
  audit?: TermsAndConditionsQueryModelAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  description?: string | null;
  displayOrder?: number;
  status?: string;
  product?: ProductQueryModel;
  accepted?: string | null;
  acceptedBy?: ExtendedIdentityQueryModel;
};

