/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Agreement } from './Agreement';
import type { AgreementLine } from './AgreementLine';
import type { Asset } from './Asset';
import type { Authorization } from './Authorization';
import type { BillingType } from './BillingType';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { ChargeAttributes } from './ChargeAttributes';
import type { ChargeAuditBag } from './ChargeAuditBag';
import type { ChargeDescription } from './ChargeDescription';
import type { ChargeExternalIds } from './ChargeExternalIds';
import type { ChargePrice } from './ChargePrice';
import type { ChargeSearchBag } from './ChargeSearchBag';
import type { ChargeSplit } from './ChargeSplit';
import type { ChargeStatusBag } from './ChargeStatusBag';
import type { CustomLedger } from './CustomLedger';
import type { DatePeriod } from './DatePeriod';
import type { ErpData } from './ErpData';
import type { Journal } from './Journal';
import type { Ledger } from './Ledger';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { Order } from './Order';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProductItemEntity } from './ProductItemEntity';
import type { Reconciliation } from './Reconciliation';
import type { SellerQueryModel } from './SellerQueryModel';
import type { Statement } from './Statement';
import type { StatementType } from './StatementType';
import type { Subscription } from './Subscription';
/**
 * Represents a charge in the billing system.
 */
export type Charge = {
  /**
   * Represents a container for audit-related events for a charge
   */
  audit?: ChargeAuditBag;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * The unique identifier of the charge.
   */
  id?: string;
  /**
   * Contains external identifiers associated with the charge.
   */
  externalIds?: ChargeExternalIds;
  /**
   * Contains search-related details for the charge.
   */
  search?: ChargeSearchBag;
  /**
   * Represents the period during which the charge is applicable.
   */
  period?: DatePeriod;
  /**
   * Indicates the quantity associated with the charge.
   */
  quantity?: number;
  /**
   * Contains pricing details for the charge.
   */
  price?: ChargePrice;
  /**
   * Contains a description of the charge, if applicable.
   */
  description?: ChargeDescription | null;
  /**
   * Contains additional attributes for the charge.
   */
  attributes?: ChargeAttributes;
  /**
   * The journal associated with the charge, if applicable.
   */
  journal?: Journal | null;
  /**
   * The ledger associated with the charge, if applicable.
   */
  ledger?: Ledger | null;
  /**
   * The custom ledger associated with the charge, if applicable.
   */
  customLedger?: CustomLedger | null;
  /**
   * The parent charge, if this charge is part of a hierarchy.
   */
  parent?: Charge | null;
  /**
   * Indicates the billing type of the charge, defaulting to automated.
   */
  readonly billingType?: BillingType;
  /**
   * Contains the upload status and related details for the charge, visible to vendors or operations.
   */
  upload?: ChargeStatusBag;
  /**
   * The licensee associated with the charge, if applicable.
   */
  licensee?: LicenseeQueryModel | null;
  /**
   * The agreement associated with the charge, if applicable.
   */
  agreement?: Agreement | null;
  /**
   * The subscription associated with the charge, if applicable.
   */
  subscription?: Subscription | null;
  /**
   * The line associated with the charge, if applicable.
   */
  line?: AgreementLine | null;
  /**
   * The order associated with the charge, if applicable.
   */
  order?: Order | null;
  /**
   * The asset associated with the charge, if applicable.
   */
  asset?: Asset | null;
  /**
   * The product item associated with the charge, if applicable.
   */
  item?: ProductItemEntity | null;
  /**
   * The authorization details associated with the charge, if applicable.
   */
  authorization?: Authorization | null;
  /**
   * The statement associated with the charge, if applicable.
   */
  statement?: Statement | null;
  /**
   * Indicates the type of statement associated with the charge.
   */
  statementType?: StatementType;
  /**
   * Contains the processing status and related details for the charge, visible to operations.
   */
  processing?: ChargeStatusBag;
  /**
   * Contains ERP-related data for the charge.
   */
  erpData?: ErpData;
  /**
   * The buyer associated with the charge.
   */
  buyer?: BuyerQueryModel;
  /**
   * The vendor associated with the charge.
   */
  vendor?: AccountQueryModel;
  /**
   * The seller associated with the charge.
   */
  seller?: SellerQueryModel;
  /**
   * Contains details about the charge split, if applicable.
   */
  split?: ChargeSplit | null;
  /**
   * Contains reconciliation info for the journal charge.
   */
  reconciliation?: Reconciliation | null;
};

