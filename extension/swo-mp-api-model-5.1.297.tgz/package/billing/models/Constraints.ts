/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Constraints = {
  hidden?: boolean | null;
  readonly?: boolean | null;
  required?: boolean | null;
};

