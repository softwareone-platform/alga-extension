/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpAddressList } from './ErpAddressList';
import type { ErpPayment } from './ErpPayment';
import type { ErpReferenceNumber } from './ErpReferenceNumber';
/**
 * Represents ERP-specific data related to an invoice.
 */
export type InvoiceErpData = {
  /**
   * The ERP system identifier for the invoice.
   */
  erpId?: string | null;
  /**
   * The document number assigned by the ERP system.
   */
  documentNo?: string;
  /**
   * The country code of the credit memo.
   */
  countryCode?: string;
  /**
   * The date when the document was created.
   */
  documentDate?: string | null;
  /**
   * The due date for the invoice payment.
   */
  dueDate?: string | null;
  /**
   * The external document number associated with the invoice.
   */
  externalDocumentNo?: string | null;
  /**
   * The second external document number associated with the invoice.
   */
  externalDocumentNo2?: string | null;
  /**
   * The remaining balance due on the invoice.
   */
  balanceDue?: number | null;
  /**
   * The total amount of the invoice.
   */
  invoiceTotal?: number | null;
  /**
   * The date when the invoice was posted.
   */
  postingDate?: string;
  /**
   * The revision of the invoice, used for versioning control.
   */
  revision?: number | null;
  /**
   * The row version of the invoice, used for concurrency control.
   */
  rowVersion?: number | null;
  /**
   * Can be the custom reference (free text) or the statement ID (fixed format).
   */
  yourReference?: string | null;
  /**
   * The list of addresses associated with the invoice.
   */
  addresses?: ErpAddressList;
  /**
   * The additional identifiers related to the invoice.
   */
  referenceNumber?: ErpReferenceNumber | null;
  /**
   * The payment data associated with the invoice.
   */
  payment?: ErpPayment | null;
};

