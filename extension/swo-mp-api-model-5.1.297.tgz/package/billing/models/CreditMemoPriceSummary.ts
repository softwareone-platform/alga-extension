/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents a summary of price details for a credit memo.
 */
export type CreditMemoPriceSummary = {
  /**
   * The currency of the credit memo.
   */
  currency?: string;
  /**
   * The factor applied to the currency, used for conversion or adjustments.
   */
  currencyFactor?: number | null;
  /**
   * The second factor applied to the currency, used for conversion or adjustments.
   */
  currencyFactor2?: number | null;
  /**
   * The margin value of the credit memo, visible to operations.
   */
  margin?: number | null;
  /**
   * The markup value of the credit memo, visible to operations.
   */
  markup?: number | null;
  /**
   * The total purchase price (PP) of the credit memo, visible to operations.
   */
  totalPP?: number | null;
  /**
   * The total selling price (SP) of the credit memo, visible to clients or operations.
   */
  totalSP?: number | null;
  /**
   * The total sales tax (ST) of the credit memo, visible to clients or operations.
   */
  totalST?: number | null;
  /**
   * The total gross amount (GT) of the credit memo, visible to clients or operations.
   */
  totalGT?: number | null;
};

