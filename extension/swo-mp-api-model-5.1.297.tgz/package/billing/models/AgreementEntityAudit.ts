/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type AgreementEntityAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  active?: PlatformObjectEvent | null;
  provisioning?: PlatformObjectEvent | null;
  terminated?: PlatformObjectEvent | null;
};

