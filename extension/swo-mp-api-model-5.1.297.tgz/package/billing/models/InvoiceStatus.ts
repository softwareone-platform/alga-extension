/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the various statuses an invoice can have in the billing system.
 */
export type InvoiceStatus = 'Issued' | 'Paid' | 'Overdue';
