/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
export type ExtendedIdentityQueryModel = {
  id?: string;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  firstName?: string | null;
  lastName?: string | null;
  email?: string | null;
};

