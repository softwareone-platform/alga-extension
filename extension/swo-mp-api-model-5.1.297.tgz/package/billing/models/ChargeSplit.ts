/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the details of a charge split.
 */
export type ChargeSplit = {
  /**
   * The percentage of the charge allocated to this split.
   */
  percentage?: number;
};

