/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AnalyticsResult } from './AnalyticsResult';
import type { ListMetadata } from './ListMetadata';
export type AnalyticsResultListResponse = {
  $meta?: ListMetadata;
  data?: Array<AnalyticsResult>;
};

