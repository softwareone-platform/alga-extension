/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AddressQueryModel } from './AddressQueryModel';
import type { BuyerExternalIdsQueryModel } from './BuyerExternalIdsQueryModel';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { ErpLinkQueryModelAudit } from './ErpLinkQueryModelAudit';
import type { ErpLinkStatus } from './ErpLinkStatus';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { SellerQueryModel } from './SellerQueryModel';
export type ErpLinkQueryModel = {
  id?: string;
  audit?: ErpLinkQueryModelAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  buyer?: BuyerQueryModel;
  seller?: SellerQueryModel;
  companyName?: string | null;
  status?: ErpLinkStatus;
  note?: string | null;
  externalIds?: BuyerExternalIdsQueryModel | null;
  address?: AddressQueryModel | null;
};

