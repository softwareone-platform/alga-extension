/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
import type { ProductQueryModel } from './ProductQueryModel';
export type ItemGroupQueryModel = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  label?: string;
  description?: string | null;
  displayOrder?: number;
  default?: boolean;
  multiple?: boolean;
  required?: boolean;
  itemCount?: number;
  product?: ProductQueryModel;
};

