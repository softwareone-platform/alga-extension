/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreditMemoAttachment } from './CreditMemoAttachment';
import type { ListMetadata } from './ListMetadata';
export type CreditMemoAttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<CreditMemoAttachment>;
};

