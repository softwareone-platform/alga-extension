/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents an error related to a billing entity.
 */
export type BillingEntityError = {
  /**
   * Represents the error code associated with the billing entity.
   */
  errorCode?: string;
  /**
   * Represents the error message providing details about the issue.
   */
  errorMessage?: string;
  /**
   * Represents the unique identifier for the error, if applicable.
   */
  id?: string | null;
  /**
   * Represents the detailed message associated with the error, if applicable.
   */
  message?: string | null;
};

