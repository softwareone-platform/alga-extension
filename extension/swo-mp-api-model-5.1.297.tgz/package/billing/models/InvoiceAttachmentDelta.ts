/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { InvoiceAttachment } from './InvoiceAttachment';
export type InvoiceAttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents an attachment associated with an invoice in the billing system.
   */
  readonly data?: InvoiceAttachment | null;
  readonly isDefined?: boolean;
};

