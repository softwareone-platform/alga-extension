/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DatePeriod } from './DatePeriod';
import type { InvoiceLineErpData } from './InvoiceLineErpData';
import type { InvoiceLinePrice } from './InvoiceLinePrice';
/**
 * Represents a line item in an invoice.
 */
export type InvoiceLine = {
  /**
   * The unique identifier of the invoice line.
   */
  id?: string;
  /**
   * The primary description of the line item.
   */
  description?: string | null;
  /**
   * The secondary description of the line item, if any.
   */
  description2?: string | null;
  /**
   * The document number associated with the invoice line.
   */
  documentNo?: string;
  /**
   * The ERP-specific data related to the credit memo line.
   */
  erpData?: InvoiceLineErpData | null;
  /**
   * The item number associated with the line item.
   */
  itemNo?: string | null;
  /**
   * The line number within the invoice.
   */
  lineNo?: number;
  /**
   * The period associated with the line item, if any.
   */
  period?: DatePeriod | null;
  /**
   * The price details for the line.
   */
  price?: InvoiceLinePrice | null;
};

