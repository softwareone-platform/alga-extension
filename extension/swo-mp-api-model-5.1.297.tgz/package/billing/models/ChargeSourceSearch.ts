/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { JournalChargeSource } from './JournalChargeSource';
/**
 * Represents a search criterion and its value for a charge.
 */
export type ChargeSourceSearch = {
  /**
   * The search criterion used for the charge.
   */
  criteria?: string;
  /**
   * The value associated with the search criterion.
   */
  value?: string;
  /**
   * Source type
   */
  type?: JournalChargeSource;
};

