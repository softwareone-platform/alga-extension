/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreditMemoAttachment } from './CreditMemoAttachment';
import type { DeltaNode } from './DeltaNode';
export type CreditMemoAttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents an attachment associated with a credit memo in the billing system.
   */
  readonly data?: CreditMemoAttachment | null;
  readonly isDefined?: boolean;
};

