/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Bucket } from './Bucket';
import type { DateRange } from './DateRange';
/**
 * Represents analytics result data with date-based buckets and aggregated values.
 */
export type AnalyticsResult = {
  /**
   * Date range for the analytics data.
   */
  range?: DateRange;
  /**
   * Buckets of grouped data.
   */
  buckets?: Array<Bucket>;
};

