/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the various statuses a charge can have in the billing system.
 */
export type ChargeStatus = 'Ready' | 'Error' | 'Split' | 'Skipped' | 'Ignored' | 'Reconciling';
