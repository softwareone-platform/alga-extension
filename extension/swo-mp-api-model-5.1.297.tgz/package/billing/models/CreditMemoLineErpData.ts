/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpCode } from './ErpCode';
/**
 * Represents ERP-specific data related to a credit memo line.
 */
export type CreditMemoLineErpData = {
  /**
   * The contract number associated with the credit memo line.
   */
  contractNo?: string | null;
  /**
   * The country of usage for the credit memo line.
   */
  countryOfUsage?: string | null;
  /**
   * The data origin for the credit memo line.
   */
  dataOrigin?: number | null;
  /**
   * The external position number for the credit memo line.
   */
  externalPositionNo?: string | null;
  /**
   * The Navision country code for the credit memo line.
   */
  navisionCountryCode?: string;
  /**
   * The parent item number for the credit memo line.
   */
  parentItemNo?: string | null;
  /**
   * The primary code details for the credit memo line, if any.
   */
  primary?: ErpCode;
  /**
   * The secondary code details for the credit memo line, if any.
   */
  secondary?: ErpCode;
  /**
   * The row version of the credit memo line, for concurrency control.
   */
  rowVersion?: number | null;
  /**
   * The responsibility center code for the credit memo line.
   */
  responsibilityCenterCode?: string | null;
  /**
   * The SWO purchase order number for the credit memo line.
   */
  swoPurchaseOrderNo?: string | null;
  /**
   * The type of the credit memo line.
   */
  type?: number | null;
  /**
   * The unit of measure for the credit memo line.
   */
  unitOfMeasure?: string | null;
  /**
   * The VAR agreement number for the credit memo line.
   */
  varAgreementNo?: string | null;
  /**
   * The VAR partner number for the credit memo line.
   */
  varPartnerNo?: string | null;
};

