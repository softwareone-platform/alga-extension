/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents an address with various details such as name, address lines, city, postcode, country, and contact name.
 */
export type ErpAddress = {
  /**
   * The primary name associated with the address.
   */
  name?: string;
  /**
   * The secondary name associated with the address.
   */
  name2?: string | null;
  /**
   * The email associated with the address.
   */
  email?: string | null;
  /**
   * The customer number associated with the address.
   */
  customerNo?: string | null;
  /**
   * The first line of the address.
   */
  addressLine1?: string;
  /**
   * The second line of the address.
   */
  addressLine2?: string | null;
  /**
   * The third line of the address.
   */
  addressLine3?: string | null;
  /**
   * The city of the address.
   */
  city?: string | null;
  /**
   * The postal code of the address.
   */
  postCode?: string | null;
  /**
   * The county/state/region of the address.
   */
  county?: string | null;
  /**
   * The country of the address.
   */
  country?: string | null;
  /**
   * The contact name associated with the address.
   */
  contactName?: string | null;
  /**
   * The contact number associated with the address.
   */
  contactNo?: string | null;
  /**
   * The contact email associated with the address.
   */
  contactEmail?: string | null;
  /**
   * The contact phone number associated with the address.
   */
  contactPhone?: string | null;
  /**
   * The code associated with the address.
   */
  code?: string | null;
};

