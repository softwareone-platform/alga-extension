/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents external identifiers associated with a charge.
 */
export type ChargeExternalIds = {
  /**
   * A reference identifier for the charge, if applicable.
   */
  reference?: string | null;
  /**
   * The invoice identifier associated with the charge.
   */
  invoice?: string;
  /**
   * The vendor identifier associated with the charge.
   */
  vendor?: string;
};

