/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CustomLedger } from './CustomLedger';
import type { DeltaNode } from './DeltaNode';
export type CustomLedgerDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents a custom ledger in the billing system.
   */
  readonly data?: CustomLedger | null;
  readonly isDefined?: boolean;
};

