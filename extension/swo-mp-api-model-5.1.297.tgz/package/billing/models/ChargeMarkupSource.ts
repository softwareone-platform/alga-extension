/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Specifies the source of the markup value.
 */
export type ChargeMarkupSource = 'Subscription' | 'Line' | 'Agreement' | 'Asset';
