/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpAddress } from './ErpAddress';
/**
 * Represents a list of addresses for billing purposes.
 */
export type ErpAddressList = {
  /**
   * The bill to address.
   */
  billTo?: ErpAddress;
  /**
   * The license to address.
   */
  licenseTo?: ErpAddress | null;
  /**
   * The sell to address.
   */
  sellTo?: ErpAddress | null;
  /**
   * The ship to address.
   */
  shipTo?: ErpAddress | null;
};

