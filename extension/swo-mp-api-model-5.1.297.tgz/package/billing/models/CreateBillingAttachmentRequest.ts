/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CreateBillingAttachmentRequest = {
  /**
   * Json representation of the attachment
   */
  attachment?: {
    /**
     * The name of the attachment.
     */
    Name?: string;
    /**
     * The description of the attachment.
     */
    Description?: string;
  };
  /**
   * The file of the attachment.
   */
  file?: Blob;
};

