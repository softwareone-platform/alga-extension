/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents ERP-specific data related to a credit memo line or invoice line.
 */
export type ErpCode = {
  /**
   * The unique identifier for the ERP code.
   */
  identifier?: string;
  /**
   * The value of the ERP code.
   */
  value?: string | null;
  /**
   * The version of the ERP code.
   */
  version?: string | null;
};

