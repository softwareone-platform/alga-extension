/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { CertificateEntityAudit } from './CertificateEntityAudit';
import type { CertificateExternalIds } from './CertificateExternalIds';
import type { CertificateStatus } from './CertificateStatus';
import type { CertificateTermsEntity } from './CertificateTermsEntity';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProgramApplicableTo } from './ProgramApplicableTo';
import type { ProgramEligibility } from './ProgramEligibility';
import type { ProgramEntity } from './ProgramEntity';
import type { ProgramParameterBag } from './ProgramParameterBag';
import type { ProgramTemplateEntity } from './ProgramTemplateEntity';
export type CertificateEntity = {
  id?: string;
  audit?: CertificateEntityAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  program?: ProgramEntity;
  externalIds?: CertificateExternalIds;
  client?: AccountQueryModel | null;
  applicableTo?: ProgramApplicableTo;
  buyer?: BuyerQueryModel | null;
  licensee?: LicenseeQueryModel | null;
  eligibility?: ProgramEligibility;
  status?: CertificateStatus;
  expirationDate?: string | null;
  template?: ProgramTemplateEntity | null;
  parameters?: ProgramParameterBag;
  terms?: Array<CertificateTermsEntity> | null;
};

