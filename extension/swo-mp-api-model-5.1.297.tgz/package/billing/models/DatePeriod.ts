/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the period during which a charge is applicable.
 */
export type DatePeriod = {
  /**
   * The start date and time of the period.
   */
  start?: string;
  /**
   * The end date and time of the period.
   */
  end?: string;
};

