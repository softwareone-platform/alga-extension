/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Invoice } from './Invoice';
import type { ListMetadata } from './ListMetadata';
export type InvoiceListResponse = {
  $meta?: ListMetadata;
  data?: Array<Invoice>;
};

