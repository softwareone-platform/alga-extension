/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { InvoiceAttachment } from './InvoiceAttachment';
import type { ListMetadata } from './ListMetadata';
export type InvoiceAttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<InvoiceAttachment>;
};

