/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents a date range with from and to dates.
 */
export type DateRange = {
  /**
   * Start date of the range.
   */
  from?: string;
  /**
   * End date of the range.
   */
  to?: string;
};

