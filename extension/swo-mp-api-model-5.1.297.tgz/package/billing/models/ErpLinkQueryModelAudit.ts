/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type ErpLinkQueryModelAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  blocked?: PlatformObjectEvent | null;
  unblocked?: PlatformObjectEvent | null;
};

