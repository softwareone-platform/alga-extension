/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents reference numbers associated with an ERP system.
 */
export type ErpReferenceNumber = {
  /**
   * The e-invoice number associated with the invoice.
   */
  eInvoiceNo?: string | null;
  /**
   * The order number associated with the invoice. Also known as "Sales Order ID".
   */
  orderNo?: string;
  /**
   * The PPQ number associated with the invoice.
   */
  ppqNo?: string | null;
  /**
   * The quote number associated with the invoice.
   */
  quoteNo?: string | null;
};

