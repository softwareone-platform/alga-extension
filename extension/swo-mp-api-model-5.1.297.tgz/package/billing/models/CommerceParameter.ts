/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ParameterConstraints } from './ParameterConstraints';
import type { ParameterPhase } from './ParameterPhase';
import type { ParameterType } from './ParameterType';
import type { ParametrisedMessage } from './ParametrisedMessage';
export type CommerceParameter = {
  id?: string;
  externalId?: string | null;
  name?: string;
  type?: ParameterType;
  phase?: ParameterPhase;
  error?: ParametrisedMessage | null;
  constraints?: ParameterConstraints | null;
  displayValue?: string | null;
  value?: any;
};

