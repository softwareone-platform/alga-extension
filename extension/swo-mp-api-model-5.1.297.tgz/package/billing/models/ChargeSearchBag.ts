/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChargeSearch } from './ChargeSearch';
import type { ChargeSourceSearch } from './ChargeSourceSearch';
/**
 * Represents search-related details for a charge.
 */
export type ChargeSearchBag = {
  /**
   * Contains subscription-related search details for the charge, if applicable.
   */
  source?: ChargeSourceSearch;
  /**
   * Contains order-related search details for the charge, if applicable.
   */
  order?: ChargeSearch | null;
  /**
   * Contains item-related search details for the charge, if applicable.
   */
  item?: ChargeSearch | null;
};

