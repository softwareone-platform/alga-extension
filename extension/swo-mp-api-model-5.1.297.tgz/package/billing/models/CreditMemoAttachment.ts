/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BillingAttachmentType } from './BillingAttachmentType';
import type { CreditMemo } from './CreditMemo';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
/**
 * Represents an attachment associated with a credit memo in the billing system.
 */
export type CreditMemoAttachment = {
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * Name of the attachment.
   */
  name?: string;
  /**
   * Specifies the type of the attachment, such as input, output, or general attachment.
   */
  type?: BillingAttachmentType;
  /**
   * Represents the name of the file associated with the attachment.
   */
  filename?: string;
  /**
   * Indicates the size of the file in bytes.
   */
  size?: number | null;
  /**
   * Represents the MIME type of the file content.
   */
  contentType?: string;
  /**
   * Provides a description of the attachment.
   */
  description?: string;
  /**
   * Indicates whether the attachment has been marked as deleted.
   */
  isDeleted?: boolean;
  /**
   * The unique identifier of the attachment.
   */
  id?: string;
  /**
   * Represents the credit memo associated with this attachment.
   */
  creditMemo?: CreditMemo | null;
  /**
   * Indicates whether the attachment is stored externally
   */
  isExternal?: boolean;
};

