/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type CertificateEntityAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  activated?: PlatformObjectEvent | null;
  pending?: PlatformObjectEvent | null;
  terminated?: PlatformObjectEvent | null;
  expired?: PlatformObjectEvent | null;
  updating?: PlatformObjectEvent | null;
};

