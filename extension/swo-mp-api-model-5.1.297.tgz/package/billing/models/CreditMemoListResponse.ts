/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreditMemo } from './CreditMemo';
import type { ListMetadata } from './ListMetadata';
export type CreditMemoListResponse = {
  $meta?: ListMetadata;
  data?: Array<CreditMemo>;
};

