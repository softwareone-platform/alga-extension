/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Charge } from './Charge';
import type { ListMetadata } from './ListMetadata';
export type ChargeListResponse = {
  $meta?: ListMetadata;
  data?: Array<Charge>;
};

