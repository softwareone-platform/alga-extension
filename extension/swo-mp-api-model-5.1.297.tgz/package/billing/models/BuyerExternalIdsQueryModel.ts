/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type BuyerExternalIdsQueryModel = {
  erpCompanyContact?: string | null;
  erpCustomer?: string | null;
  accountExternalId?: string | null;
};

