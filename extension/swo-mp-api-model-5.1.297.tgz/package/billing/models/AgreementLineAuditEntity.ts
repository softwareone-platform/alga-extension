/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type AgreementLineAuditEntity = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  terminated?: PlatformObjectEvent | null;
  deleted?: PlatformObjectEvent | null;
};

