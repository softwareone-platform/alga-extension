/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CommerceParameter } from './CommerceParameter';
export type AssetEntityParameterBag = {
  fulfillment?: Array<CommerceParameter> | null;
};

