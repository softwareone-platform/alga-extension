/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents external identifiers associated with billing entities.
 */
export type BillingExternalIds = {
  /**
   * Represents the identifier used for operations in the billing system.
   */
  operations?: string | null;
  /**
   * Represents the identifier used for vendors in the billing system.
   */
  vendor?: string | null;
};

