/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChargeMarkupSource } from './ChargeMarkupSource';
import type { PriceCurrency } from './PriceCurrency';
/**
 * Represents the pricing details of a charge, including currency, markup, margin, and unit prices.
 */
export type ChargePrice = {
  /**
   * Specifies the currency details for the charge, including purchase and sale values.
   */
  currency?: PriceCurrency;
  /**
   * Represents the markup value applied to the charge.
   */
  markup?: number | null;
  /**
   * Specifies the source of the markup value.
   */
  markupSource?: ChargeMarkupSource | null;
  /**
   * Represents the margin value calculated for the charge.
   */
  margin?: number | null;
  /**
   * Represents the unit purchase price of the charge.
   */
  unitPP?: number | null;
  /**
   * Represents an total purchase price value for the charge.
   */
  PPx1?: number | null;
  /**
   * Represents the unit sale price of the charge in buyer currency.
   */
  unitBSP?: number | null;
  /**
   * Represents an total sale price value for the charge in buyer currency.
   */
  BSPx1?: number | null;
  /**
   * Represents the unit sale price of the charge.
   */
  unitSP?: number | null;
  /**
   * Represents an total sale price value for the charge.
   */
  SPx1?: number | null;
};

