/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the price details of a credit memo line.
 */
export type CreditMemoLinePrice = {
  /**
   * The amount for the credit memo line, visible to clients or operations.
   */
  amount?: number | null;
  /**
   * The amount including VAT for the credit memo line, visible to clients or operations.
   */
  amountIncludingVat?: number | null;
  /**
   * The discount amount for the credit memo line, visible to clients or operations.
   */
  discountAmount?: number | null;
  /**
   * The invoice discount amount for the credit memo line, visible to clients or operations.
   */
  invoiceDiscountAmount?: number | null;
  /**
   * The line amount for the credit memo line, visible to clients or operations.
   */
  lineAmount?: number | null;
  /**
   * The currency used for the purchase price, visible only to operations.
   */
  purchaseCurrencyCode?: string | null;
  /**
   * The factor applied to the purchase currency, visible only to operations.
   */
  purchaseCurrencyFactor?: number | null;
  /**
   * The purchase price for the credit memo line, visible only to operations.
   */
  purchasePrice?: number;
  /**
   * The purchase price in local currency for the credit memo line, visible only to operations.
   */
  purchasePriceLcy?: number;
  /**
   * The total purchase price for the credit memo line, visible only to operations.
   */
  purchasePriceTotal?: number;
  /**
   * The total purchase price in local currency for the credit memo line, visible only to operations.
   */
  purchasePriceTotalLcy?: number;
  /**
   * The quantity for the credit memo line.
   */
  quantity?: number;
  /**
   * The sales markup for the credit memo line, visible only to operations.
   */
  salesMarkup?: number | null;
  /**
   * The sales margin for the credit memo line, visible only to operations.
   */
  salesMargin?: number | null;
  /**
   * The unit price for the credit memo line.
   */
  unitPrice?: number | null;
  /**
   * The VAT base amount for the credit memo line.
   */
  vatBaseAmount?: number;
  /**
   * The VAT calculation type for the credit memo line.
   */
  vatCalculationType?: number | null;
  /**
   * The VAT percentage for the credit memo line.
   */
  vatPercent?: number | null;
};

