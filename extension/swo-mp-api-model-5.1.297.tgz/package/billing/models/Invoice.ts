/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Agreement } from './Agreement';
import type { BillingType } from './BillingType';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { ErpExternalIds } from './ErpExternalIds';
import type { InvoiceAuditBag } from './InvoiceAuditBag';
import type { InvoiceErpAttributes } from './InvoiceErpAttributes';
import type { InvoiceErpData } from './InvoiceErpData';
import type { InvoiceLine } from './InvoiceLine';
import type { InvoicePrice } from './InvoicePrice';
import type { InvoiceStatus } from './InvoiceStatus';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
import type { Statement } from './Statement';
/**
 * Represents an invoice entity in the billing system.
 */
export type Invoice = {
  /**
   * Represents a container for audit-related events for an invoice
   */
  audit?: InvoiceAuditBag;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * The unique identifier of the invoice.
   */
  id?: string;
  /**
   * The country code.
   */
  countryCode?: string;
  /**
   * The document number assigned by the ERP system.
   */
  documentNo?: string;
  /**
   * Invoice external ids.
   */
  externalIds?: ErpExternalIds;
  /**
   * The buyer associated with the invoice.
   */
  buyer?: BuyerQueryModel;
  /**
   * The seller associated with the invoice.
   */
  seller?: SellerQueryModel;
  /**
   * ERP attributes associated with the entity.
   */
  attributes?: InvoiceErpAttributes;
  /**
   * The current status of the invoice.
   */
  status?: InvoiceStatus;
  /**
   * The statement linked to the invoice, if any.
   */
  statement?: Statement | null;
  /**
   * The agreement linked to the invoice, if any.
   */
  agreement?: Agreement | null;
  /**
   * The billing type associated with the invoice.
   */
  billingType?: BillingType;
  /**
   * The client associated with the invoice, if any.
   */
  client?: AccountQueryModel | null;
  /**
   * The licensee associated with the invoice, if any.
   */
  licensee?: LicenseeQueryModel | null;
  /**
   * The product associated with the invoice, if any.
   */
  product?: ProductQueryModel | null;
  /**
   * The vendor associated with the invoice, if any.
   */
  vendor?: AccountQueryModel | null;
  /**
   * ERP-specific data related to the invoice, if available.
   */
  erpData?: InvoiceErpData;
  /**
   * Pricing details of the invoice, if available.
   */
  price?: InvoicePrice;
  /**
   * The list of invoice lines associated with the invoice.
   */
  lines?: Array<InvoiceLine>;
};

