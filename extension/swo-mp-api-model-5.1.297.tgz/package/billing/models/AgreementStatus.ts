/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AgreementStatus = 'New' | 'Draft' | 'Provisioning' | 'Updating' | 'Active' | 'Terminated' | 'Failed' | 'Deleted';
