/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the various statuses a custom ledger can have in the billing system.
 */
export type CustomLedgerStatus = 'Draft' | 'Deleted' | 'Validating' | 'Validated' | 'Error' | 'Generating' | 'Generated' | 'Queued' | 'Completed';
