/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Agreement } from './Agreement';
import type { AgreementLine } from './AgreementLine';
import type { AssetEntityAudit } from './AssetEntityAudit';
import type { AssetEntityParameterBag } from './AssetEntityParameterBag';
import type { AssetStatus } from './AssetStatus';
import type { AssetSummaryPrice } from './AssetSummaryPrice';
import type { ExternalIds } from './ExternalIds';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { ListingEntity } from './ListingEntity';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PriceList } from './PriceList';
import type { ProductQueryModel } from './ProductQueryModel';
import type { TemplateEntity } from './TemplateEntity';
import type { TermsEntity } from './TermsEntity';
export type Asset = {
  id?: string;
  audit?: AssetEntityAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  externalIds?: ExternalIds;
  status?: AssetStatus;
  price?: AssetSummaryPrice;
  template?: TemplateEntity | null;
  parameters?: AssetEntityParameterBag;
  terms?: TermsEntity;
  agreement?: Agreement;
  product?: ProductQueryModel;
  priceList?: PriceList;
  listing?: ListingEntity;
  licensee?: LicenseeQueryModel;
  lines?: Array<AgreementLine> | null;
};

