/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Attributes related to ERP systems for an invoice.
 */
export type InvoiceErpAttributes = {
  /**
   * The date when the invoice was posted.
   */
  postingDate?: string | null;
  /**
   * The date when the document was created.
   */
  documentDate?: string | null;
  /**
   * The external document number associated with the invoice.
   */
  externalDocumentNo?: string | null;
  /**
   * The second external document number associated with the invoice.
   */
  externalDocumentNo2?: string | null;
  /**
   * Can be the custom reference (free text) or the statement ID (fixed format).
   */
  yourReference?: string | null;
  /**
   * The due date for the invoice payment.
   */
  dueDate?: string | null;
  /**
   * The order number associated with the invoice. Also known as "Sales Order ID".
   */
  orderNo?: string | null;
  /**
   * The quote number associated with the invoice.
   */
  quoteNo?: string | null;
};

