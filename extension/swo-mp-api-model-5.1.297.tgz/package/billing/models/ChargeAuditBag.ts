/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Represents a container for audit-related events for a charge
 */
export type ChargeAuditBag = {
  /**
   * Contains details about the most recent event when the charge was reconciled.
   */
  reconciled?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the charge was reset (undoing previous reconcile actions).
   */
  reset?: PlatformObjectEvent | null;
};

