/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { AuthorizationEligibility } from './AuthorizationEligibility';
import type { AuthorizationExternalIdBag } from './AuthorizationExternalIdBag';
import type { AuthorizationJournal } from './AuthorizationJournal';
import type { AuthorizationStatistics } from './AuthorizationStatistics';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { PlatformObjectAudit } from './PlatformObjectAudit';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
export type Authorization = {
  id?: string;
  audit?: PlatformObjectAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  revision?: number;
  externalIds?: AuthorizationExternalIdBag;
  currency?: string;
  notes?: string | null;
  product?: ProductQueryModel;
  vendor?: AccountQueryModel;
  owner?: SellerQueryModel;
  statistics?: AuthorizationStatistics;
  journal?: AuthorizationJournal;
  eligibility?: AuthorizationEligibility;
  settings?: string | null;
};

