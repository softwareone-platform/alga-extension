/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents a search criterion and its value for a charge.
 */
export type ChargeSearch = {
  /**
   * The search criterion used for the charge.
   */
  criteria?: string;
  /**
   * The value associated with the search criterion.
   */
  value?: string;
};

