/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AuthorizationJournal = {
  firstInvoiceDate?: string;
  frequency?: '1m' | '6m' | '1y' | '3m' | '3y' | 'one-time';
};

