/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { JournalAttachment } from './JournalAttachment';
import type { ListMetadata } from './ListMetadata';
export type JournalAttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<JournalAttachment>;
};

