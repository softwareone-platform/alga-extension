/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the type of billing process.
 */
export type BillingType = 'Automated' | 'Manual';
