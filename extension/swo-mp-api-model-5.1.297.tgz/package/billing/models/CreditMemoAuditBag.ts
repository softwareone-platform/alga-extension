/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Represents a container for audit-related events for a credit memo
 */
export type CreditMemoAuditBag = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the credit memo reached the "Issued" status.
   */
  issued?: PlatformObjectEvent | null;
};

