/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents ERP-related data associated with a charge in the billing system.
 */
export type ErpData = {
  /**
   * The country code used in the ERP system.
   */
  erpCountryCode?: string;
  /**
   * The default product identifier used in the ERP system.
   */
  defaultErpProductId?: string;
  /**
   * The default product name used in the ERP system.
   */
  defaultErpProductName?: string;
  /**
   * The CDG (Customer Designation Group) value associated with the ERP data.
   */
  cdg?: string;
  /**
   * The SCU (Service Configuration Unit) value associated with the ERP data.
   */
  scu?: string;
  /**
   * The CCO (Customer Configuration Option) value associated with the ERP data.
   */
  cco?: string;
  /**
   * The item identifier used in the ERP system.
   */
  erpItemId?: string;
};

