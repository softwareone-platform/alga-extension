/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CustomLedgerAttachment } from './CustomLedgerAttachment';
import type { ListMetadata } from './ListMetadata';
export type CustomLedgerAttachmentListResponse = {
  $meta?: ListMetadata;
  data?: Array<CustomLedgerAttachment>;
};

