/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpAddressList } from './ErpAddressList';
/**
 * Represents ERP-specific data related to a credit memo.
 */
export type CreditMemoErpData = {
  /**
   * The list of addresses associated with the credit memo.
   */
  addresses?: ErpAddressList;
  /**
   * The document number to which this credit memo applies.
   */
  appliesToDocNo?: string | null;
  /**
   * The currency code of the credit memo.
   */
  currencyCode?: string | null;
  /**
   * The document date of the credit memo.
   */
  documentDate?: string | null;
  /**
   * The document number of the credit memo.
   */
  documentNo?: string;
  /**
   * The external document number of the credit memo.
   */
  externalDocumentNo?: string | null;
  /**
   * The second external document number of the credit memo.
   */
  externalDocumentNo2?: string | null;
  /**
   * The inside sales code associated with the credit memo.
   */
  insideSalesCode?: string | null;
  /**
   * The Navision country code of the credit memo.
   */
  navisionCountryCode?: string;
  /**
   * The posting date of the credit memo.
   */
  postingDate?: string;
  /**
   * The revision of the invoice, used for versioning control.
   */
  revision?: number | null;
  /**
   * The row version of the credit memo, used for concurrency control.
   */
  rowVersion?: number | null;
  /**
   * The responsibility center code of the credit memo.
   */
  responsibilityCenterCode?: string | null;
  /**
   * The sales person code of the credit memo.
   */
  salesPersonCode?: string | null;
  /**
   * The shipment method code of the credit memo.
   */
  shipmentMethodCode?: string | null;
  /**
   * The VAT registration number of the credit memo.
   */
  vatRegistrationNo?: string | null;
  /**
   * The reference provided by the customer.
   */
  yourReference?: string | null;
};

