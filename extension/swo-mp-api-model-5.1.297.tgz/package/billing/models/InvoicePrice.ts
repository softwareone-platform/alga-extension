/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the pricing details of an invoice.
 */
export type InvoicePrice = {
  /**
   * The currency used for the invoice pricing.
   */
  currency?: string;
  /**
   * The factor applied to the currency, used for conversion or adjustments.
   */
  currencyFactor?: number | null;
  /**
   * The second factor applied to the currency, used for conversion or adjustments.
   */
  currencyFactor2?: number | null;
  /**
   * The markup applied to the invoice, visible to operations.
   */
  markup?: number | null;
  /**
   * The margin applied to the invoice, visible to operations.
   */
  margin?: number | null;
  /**
   * The total purchase price, visible to operations.
   */
  totalPP?: number | null;
  /**
   * The total selling price, visible to clients or operations.
   */
  totalSP?: number | null;
  /**
   * The total sales tax, visible to clients or operations.
   */
  totalST?: number | null;
  /**
   * The total gross amount, visible to clients or operations.
   */
  totalGT?: number | null;
};

