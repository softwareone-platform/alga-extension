/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CustomLedger } from './CustomLedger';
import type { ListMetadata } from './ListMetadata';
export type CustomLedgerListResponse = {
  $meta?: ListMetadata;
  data?: Array<CustomLedger>;
};

