/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Represents a container for audit-related events for an invoice
 */
export type InvoiceAuditBag = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the invoice reached the "Issued" status.
   */
  issued?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the invoice reached the "Paid" status.
   */
  paid?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the invoice reached the "Overdue" status.
   */
  overdue?: PlatformObjectEvent | null;
};

