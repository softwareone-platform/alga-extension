/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
/**
 * Represents a container for audit-related events for a custom ledger
 */
export type CustomLedgerAuditBag = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Draft" status.
   */
  draft?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Deleted" status.
   */
  deleted?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Validating" status.
   */
  validating?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Validated" status.
   */
  validated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Error" status.
   */
  error?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Generating" status.
   */
  generating?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Generated" status.
   */
  generated?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Queued" status.
   */
  queued?: PlatformObjectEvent | null;
  /**
   * Contains details about the most recent event when the custom ledger reached the "Completed" status.
   */
  completed?: PlatformObjectEvent | null;
};

