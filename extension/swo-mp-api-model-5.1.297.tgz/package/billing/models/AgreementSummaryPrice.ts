/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { MarkupSourcePrice } from './MarkupSourcePrice';
export type AgreementSummaryPrice = {
  currency?: string;
  markup?: number;
  margin?: number;
  defaultMarkupSource?: MarkupSourcePrice | null;
  markupSource?: MarkupSourcePrice | null;
  SPxY?: number | null;
  SPxM?: number | null;
  PPxY?: number | null;
  PPxM?: number | null;
  defaultMarkup?: number | null;
  defaultMargin?: number | null;
};

