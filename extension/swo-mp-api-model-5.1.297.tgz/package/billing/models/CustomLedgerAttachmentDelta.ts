/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CustomLedgerAttachment } from './CustomLedgerAttachment';
import type { DeltaNode } from './DeltaNode';
export type CustomLedgerAttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents an attachment associated with a custom ledger in the billing system.
   */
  readonly data?: CustomLedgerAttachment | null;
  readonly isDefined?: boolean;
};

