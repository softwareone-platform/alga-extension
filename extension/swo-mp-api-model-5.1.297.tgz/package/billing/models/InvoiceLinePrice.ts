/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents the price details of an invoice line.
 */
export type InvoiceLinePrice = {
  /**
   * The net amount of the invoice line, visible to clients or operations.
   */
  amount?: number;
  /**
   * The total amount including VAT, visible to clients or operations.
   */
  amountIncludingVat?: number;
  /**
   * The discount amount applied to the invoice line, visible to clients or operations.
   */
  discountAmount?: number;
  /**
   * The total line amount after applying discounts, visible to clients or operations.
   */
  lineAmount?: number;
  /**
   * The currency used for the purchase price, visible only to operations.
   */
  purchaseCurrencyCode?: string | null;
  /**
   * The factor applied to the purchase currency, visible only to operations.
   */
  purchaseCurrencyFactor?: number | null;
  /**
   * The purchase price, visible only to operations.
   */
  purchasePrice?: number | null;
  /**
   * The purchase price in local currency, visible only to operations.
   */
  purchasePriceLcy?: number | null;
  /**
   * The total purchase price, visible only to operations.
   */
  purchasePriceTotal?: number | null;
  /**
   * The total purchase price in local currency, visible only to operations.
   */
  purchasePriceTotalLcy?: number | null;
  /**
   * The quantity for the credit memo line.
   */
  quantity?: number | null;
  /**
   * The sales markup percentage for the invoice line, visible only to operations.
   */
  salesMarkup?: number | null;
  /**
   * The sales margin percentage for the invoice line, visible only to operations.
   */
  salesMargin?: number | null;
  /**
   * The unit price for the credit memo line.
   */
  unitPrice?: number | null;
  /**
   * The base amount used for VAT calculation.
   */
  vatBaseAmount?: number;
  /**
   * The VAT calculation type for the line.
   */
  vatCalculationType?: number | null;
  /**
   * The VAT percentage for the line.
   */
  vatPercent?: number | null;
};

