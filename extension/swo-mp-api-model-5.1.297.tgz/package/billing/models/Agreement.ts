/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { AgreementEntityAudit } from './AgreementEntityAudit';
import type { AgreementLine } from './AgreementLine';
import type { AgreementStatus } from './AgreementStatus';
import type { AgreementSummaryPrice } from './AgreementSummaryPrice';
import type { Asset } from './Asset';
import type { Authorization } from './Authorization';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { CertificateEntity } from './CertificateEntity';
import type { CommerceTermsAndConditionsEntity } from './CommerceTermsAndConditionsEntity';
import type { ExternalIds } from './ExternalIds';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { ListingEntity } from './ListingEntity';
import type { ParameterBag } from './ParameterBag';
import type { ParametrisedMessage } from './ParametrisedMessage';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
import type { SplitBillingAgreement } from './SplitBillingAgreement';
import type { Subscription } from './Subscription';
import type { TemplateEntity } from './TemplateEntity';
export type Agreement = {
  id?: string;
  audit?: AgreementEntityAudit;
  $meta?: PlatformEntityMetadata | null;
  name?: string;
  icon?: string | null;
  revision?: number;
  status?: AgreementStatus;
  listing?: ListingEntity;
  authorization?: Authorization;
  vendor?: AccountQueryModel;
  client?: AccountQueryModel;
  price?: AgreementSummaryPrice;
  startDate?: string | null;
  endDate?: string | null;
  template?: TemplateEntity | null;
  error?: ParametrisedMessage | null;
  lines?: Array<AgreementLine> | null;
  assets?: Array<Asset> | null;
  subscriptions?: Array<Subscription> | null;
  parameters?: ParameterBag;
  licensee?: LicenseeQueryModel;
  buyer?: BuyerQueryModel;
  seller?: SellerQueryModel;
  product?: ProductQueryModel;
  externalIds?: ExternalIds;
  split?: SplitBillingAgreement | null;
  termsAndConditions?: Array<CommerceTermsAndConditionsEntity>;
  certificates?: Array<CertificateEntity>;
};

