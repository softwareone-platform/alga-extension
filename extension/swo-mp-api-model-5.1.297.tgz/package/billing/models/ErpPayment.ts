/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents payment data for ERP systems.
 */
export type ErpPayment = {
  /**
   * Gets or sets the payment method code.
   */
  methodCode?: string;
  /**
   * Gets or sets the payment terms code.
   */
  termsCode?: string | null;
};

