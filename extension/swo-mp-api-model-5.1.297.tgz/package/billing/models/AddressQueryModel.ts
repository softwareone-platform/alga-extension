/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddressQueryModel = {
  addressLine1?: string | null;
  addressLine2?: string | null;
  postCode?: string | null;
  city?: string | null;
  state?: string | null;
  country?: string | null;
};

