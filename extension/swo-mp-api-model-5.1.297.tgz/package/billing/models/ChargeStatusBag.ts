/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ChargeStatus } from './ChargeStatus';
/**
 * Represents the status and associated errors of a charge in the billing system.
 */
export type ChargeStatusBag = {
  /**
   * Indicates the current status of the charge.
   */
  status?: ChargeStatus;
  /**
   * Contains a list of error messages associated with the charge, if any.
   */
  errors?: Array<string> | null;
};

