/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AccountQueryModel } from './AccountQueryModel';
import type { Agreement } from './Agreement';
import type { BuyerQueryModel } from './BuyerQueryModel';
import type { CreditMemoAuditBag } from './CreditMemoAuditBag';
import type { CreditMemoErpData } from './CreditMemoErpData';
import type { CreditMemoLine } from './CreditMemoLine';
import type { CreditMemoPriceSummary } from './CreditMemoPriceSummary';
import type { CreditMemoStatus } from './CreditMemoStatus';
import type { ErpAttributes } from './ErpAttributes';
import type { ErpExternalIds } from './ErpExternalIds';
import type { LicenseeQueryModel } from './LicenseeQueryModel';
import type { PlatformEntityMetadata } from './PlatformEntityMetadata';
import type { ProductQueryModel } from './ProductQueryModel';
import type { SellerQueryModel } from './SellerQueryModel';
import type { Statement } from './Statement';
/**
 * Represents a credit memo in the billing system.
 */
export type CreditMemo = {
  /**
   * Represents a container for audit-related events for a credit memo
   */
  audit?: CreditMemoAuditBag;
  $meta?: PlatformEntityMetadata | null;
  revision?: number;
  /**
   * The unique identifier of the credit memo.
   */
  id?: string;
  /**
   * The country code.
   */
  countryCode?: string;
  /**
   * The document number assigned by the ERP system.
   */
  documentNo?: string;
  /**
   * ERP attributes associated with the entity.
   */
  attributes?: ErpAttributes;
  /**
   * ERP-specific data related to the credit memo.
   */
  erpData?: CreditMemoErpData;
  /**
   * Credit memo external ids.
   */
  externalIds?: ErpExternalIds;
  /**
   * The agreement associated with the credit memo.
   */
  agreement?: Agreement | null;
  /**
   * The buyer associated with the credit memo.
   */
  buyer?: BuyerQueryModel | null;
  /**
   * The client associated with the credit memo.
   */
  client?: AccountQueryModel | null;
  /**
   * The licensee associated with the credit memo.
   */
  licensee?: LicenseeQueryModel | null;
  /**
   * The list of credit memo lines associated with the credit memo.
   */
  lines?: Array<CreditMemoLine>;
  /**
   * Pricing details of the credit memo.
   */
  price?: CreditMemoPriceSummary;
  /**
   * The product associated with the credit memo.
   */
  product?: ProductQueryModel | null;
  /**
   * The seller associated with the credit memo.
   */
  seller?: SellerQueryModel | null;
  /**
   * The current status of the credit memo.
   */
  status?: CreditMemoStatus;
  /**
   * The vendor associated with the credit memo.
   */
  vendor?: AccountQueryModel | null;
  /**
   * The statement associated with the credit memo.
   */
  statement?: Statement | null;
};

