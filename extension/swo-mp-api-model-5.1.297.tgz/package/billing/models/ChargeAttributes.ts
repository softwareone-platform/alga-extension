/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents additional attributes associated with a charge in the billing system.
 */
export type ChargeAttributes = {
  /**
   * The document number associated with the charge.
   */
  documentNumber?: string;
  /**
   * The type of order associated with the charge.
   */
  orderType?: string;
  /**
   * The primary external document number associated with the charge, if applicable.
   */
  externalDocumentNo?: string | null;
  /**
   * An additional external document number associated with the charge, if applicable.
   */
  externalDocumentNo2?: string | null;
  /**
   * A reference provided by the customer for the charge, if applicable.
   */
  yourReference?: string | null;
  /**
   * An identifier for the vendor's agreement related to the charge, if applicable.
   */
  agreementVendorId?: string | null;
  /**
   * Represents the segment associated with the charge.
   */
  segment?: string | null;
};

