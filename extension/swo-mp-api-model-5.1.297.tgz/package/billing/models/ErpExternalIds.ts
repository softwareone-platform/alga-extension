/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents invoice references .
 */
export type ErpExternalIds = {
  /**
   * Statement identifier.
   */
  statement?: string | null;
  /**
   * Bill to customer identifier.
   */
  customer?: string | null;
  /**
   * Agreement identifier.
   */
  agreement?: string | null;
};

