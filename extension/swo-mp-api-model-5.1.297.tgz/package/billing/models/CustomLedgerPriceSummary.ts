/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PriceCurrency } from './PriceCurrency';
/**
 * Represents a detailed summary of pricing for a custom ledger, including currency and totals.
 */
export type CustomLedgerPriceSummary = {
  /**
   * Represents the markup value applied to the pricing.
   */
  markup?: number;
  /**
   * Represents the margin value calculated for the pricing.
   */
  margin?: number;
  /**
   * Represents the total purchase price.
   */
  totalPP?: number;
  /**
   * Represents the total sale price in buyer currency.
   */
  totalBSP?: number;
  /**
   * Specifies the currency details for the pricing, including purchase and sale values.
   */
  currency?: PriceCurrency;
  /**
   * Represents the total sale price.
   */
  totalSP?: number;
};

