/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { DeltaNode } from './DeltaNode';
import type { JournalAttachment } from './JournalAttachment';
export type JournalAttachmentDelta = {
  node?: DeltaNode | null;
  path?: string;
  /**
   * Represents an attachment associated with a journal in the billing system.
   */
  readonly data?: JournalAttachment | null;
  readonly isDefined?: boolean;
};

