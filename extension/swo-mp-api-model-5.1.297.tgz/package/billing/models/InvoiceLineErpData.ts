/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ErpCode } from './ErpCode';
/**
 * Represents ERP-specific data related to a invoice line.
 */
export type InvoiceLineErpData = {
  /**
   * The contract number associated with the line.
   */
  contractNo?: string | null;
  /**
   * The country of usage for the line.
   */
  countryOfUsage?: string | null;
  /**
   * The data origin for the line.
   */
  dataOrigin?: number | null;
  /**
   * The external position number for the line.
   */
  externalPositionNo?: string | null;
  /**
   * The Navision country code for the line.
   */
  navisionCountryCode?: string | null;
  /**
   * The parent item number for the line.
   */
  parentItemNo?: string | null;
  /**
   * The primary code details for the line, if any.
   */
  primary?: ErpCode | null;
  /**
   * The secondary code details for the line, if any.
   */
  secondary?: ErpCode | null;
  /**
   * The row version of the line item for concurrency control.
   */
  rowVersion?: number | null;
  /**
   * The responsibility center code for the line.
   */
  responsibilityCenterCode?: string | null;
  /**
   * The SWO purchase order number for the line.
   */
  swoPurchaseOrderNo?: string | null;
  /**
   * The type of the line.
   */
  type?: number | null;
  /**
   * The unit of measure for the line.
   */
  unitOfMeasure?: string | null;
  /**
   * The VAR agreement number for the line.
   */
  varAgreementNo?: string | null;
  /**
   * The VAR partner number for the line.
   */
  varPartnerNo?: string | null;
  /**
   * The manufacturer's suggested retail price (MSRP) for the line item.
   */
  msrp?: number;
  /**
   * The timestamp of the line item for concurrency control.
   */
  timestamp?: number;
  /**
   * The contact number for the sell-to party, if any.
   */
  sellToContactNo?: string | null;
  /**
   * The external document number associated with the line item.
   */
  externalDocumentNo?: string | null;
  /**
   * An additional external document number, if any.
   */
  externalDocumentNo2?: string | null;
  /**
   * The reference provided by the customer for the line item.
   */
  yourReference?: string | null;
};

