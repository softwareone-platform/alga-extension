/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CreditMemoLineErpData } from './CreditMemoLineErpData';
import type { CreditMemoLinePrice } from './CreditMemoLinePrice';
import type { DatePeriod } from './DatePeriod';
/**
 * Represents a line item in a credit memo, containing details such as amounts, descriptions, and identifiers.
 */
export type CreditMemoLine = {
  /**
   * The unique identifier for the credit memo line.
   */
  id?: string;
  /**
   * The description of the credit memo line.
   */
  description?: string | null;
  /**
   * The secondary description (aka additional info) of the credit memo line.
   */
  description2?: string | null;
  /**
   * The document number associated with the credit memo line.
   */
  documentNo?: string;
  /**
   * The ERP-specific data related to the credit memo line.
   */
  erpData?: CreditMemoLineErpData;
  /**
   * The item number for the credit memo line.
   */
  itemNo?: string | null;
  /**
   * The line number for the credit memo line.
   */
  lineNo?: number;
  /**
   * The period associated with the credit memo line.
   */
  period?: DatePeriod;
  /**
   * The price details for the credit memo line.
   */
  price?: CreditMemoLinePrice;
};

