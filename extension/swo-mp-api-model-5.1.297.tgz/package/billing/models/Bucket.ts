/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
/**
 * Represents a bucket for grouping analytics data.
 */
export type Bucket = {
  /**
   * Bucket identifier.
   */
  id?: string;
  /**
   * Bucket name.
   */
  name?: string;
  /**
   * Aggregated monetary value.
   */
  value?: number;
};

