/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { PlatformObjectEvent } from './PlatformObjectEvent';
export type AssetEntityAudit = {
  created?: PlatformObjectEvent | null;
  updated?: PlatformObjectEvent | null;
  draft?: PlatformObjectEvent | null;
  active?: PlatformObjectEvent | null;
  terminated?: PlatformObjectEvent | null;
};

