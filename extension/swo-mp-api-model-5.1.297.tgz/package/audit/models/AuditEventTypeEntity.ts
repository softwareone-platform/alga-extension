/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AuditEventTypeEntity = {
  id?: string;
  key?: string;
  name?: string;
  description?: string;
};

