/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type GeolocationData = {
  countryCode?: string;
  countryName?: string;
  region?: string;
};

