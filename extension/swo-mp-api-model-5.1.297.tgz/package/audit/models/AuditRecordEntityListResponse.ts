/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditRecordEntity } from './AuditRecordEntity';
import type { ListMetadata } from './ListMetadata';
export type AuditRecordEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<AuditRecordEntity>;
};

