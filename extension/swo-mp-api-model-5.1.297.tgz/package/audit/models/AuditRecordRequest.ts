/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditRecordApiRequest } from './AuditRecordApiRequest';
import type { AuditRecordLogInfo } from './AuditRecordLogInfo';
import type { AuditRecordWorkerRequest } from './AuditRecordWorkerRequest';
export type AuditRecordRequest = {
  api?: AuditRecordApiRequest;
  worker?: AuditRecordWorkerRequest;
  log?: AuditRecordLogInfo;
};

