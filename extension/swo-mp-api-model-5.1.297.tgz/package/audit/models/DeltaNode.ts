/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type DeltaNode = {
  name?: string;
  readonly children?: Array<DeltaNode>;
};

