/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditRecordActorAccount } from './AuditRecordActorAccount';
export type AuditRecordActor = {
  id?: string;
  name?: string;
  icon?: string | null;
  account?: AuditRecordActorAccount;
};

