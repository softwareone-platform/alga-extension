/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AuditRecordObject = {
  id?: string;
  name?: string | null;
  icon?: string | null;
  objectType?: string;
};

