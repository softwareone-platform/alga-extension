/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditEventTypeEntity } from './AuditEventTypeEntity';
import type { ListMetadata } from './ListMetadata';
export type AuditEventTypeEntityListResponse = {
  $meta?: ListMetadata;
  data?: Array<AuditEventTypeEntity>;
};

