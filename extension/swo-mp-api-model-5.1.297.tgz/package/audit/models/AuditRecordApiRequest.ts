/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { GeolocationData } from './GeolocationData';
export type AuditRecordApiRequest = {
  ip?: string;
  geolocation?: GeolocationData;
  userAgent?: string;
};

