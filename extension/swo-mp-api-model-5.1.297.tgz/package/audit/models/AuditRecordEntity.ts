/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AuditRecordActor } from './AuditRecordActor';
import type { AuditRecordObject } from './AuditRecordObject';
import type { AuditRecordRequest } from './AuditRecordRequest';
import type { AuditRecordType } from './AuditRecordType';
import type { AuditRecordViewer } from './AuditRecordViewer';
import type { JsonNode } from './JsonNode';
export type AuditRecordEntity = {
  id?: string;
  event?: string;
  summary?: string;
  details?: string;
  object?: AuditRecordObject;
  timestamp?: string;
  actor?: AuditRecordActor;
  type?: AuditRecordType;
  request?: AuditRecordRequest;
  documents?: Record<string, JsonNode> | null;
  viewers?: Array<AuditRecordViewer>;
};

