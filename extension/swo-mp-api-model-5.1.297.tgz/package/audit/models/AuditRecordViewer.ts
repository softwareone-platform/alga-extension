/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AuditRecordViewer = {
  id?: string;
  name?: string | null;
  type?: string;
  icon?: string | null;
};

