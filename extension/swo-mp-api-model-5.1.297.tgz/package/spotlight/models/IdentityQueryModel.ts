/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { QueryModelAudit } from './QueryModelAudit';
import type { QueryModelMetadata } from './QueryModelMetadata';
export type IdentityQueryModel = {
  id?: string;
  audit?: QueryModelAudit;
  $meta?: QueryModelMetadata;
  name?: string;
  icon?: string | null;
};

